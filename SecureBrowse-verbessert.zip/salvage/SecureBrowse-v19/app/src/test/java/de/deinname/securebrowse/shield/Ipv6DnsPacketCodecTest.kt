package de.deinname.securebrowse.shield

import org.junit.Assert.*
import org.junit.Test

class Ipv6DnsPacketCodecTest {
    private fun dnsQuery(): ByteArray = byteArrayOf(
        0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00,
        0x03, 0x77, 0x77, 0x77, 0x07, 0x65, 0x78, 0x61,
        0x6d, 0x70, 0x6c, 0x65, 0x00, 0x00, 0x01, 0x00, 0x01
    )

    private fun ipv6Query(): ByteArray {
        val dns = dnsQuery()
        val udpLength = 8 + dns.size
        return ByteArray(40 + udpLength).also { p ->
            p[0] = 0x60
            p[4] = (udpLength ushr 8).toByte()
            p[5] = udpLength.toByte()
            p[6] = 17
            p[7] = 64
            // 2001:db8::1 -> fd77:77::2
            p[8] = 0x20; p[9] = 0x01; p[10] = 0x0d; p[11] = 0xb8.toByte(); p[23] = 1
            p[24] = 0xfd.toByte(); p[25] = 0x77; p[26] = 0; p[27] = 0x77; p[39] = 2
            p[40] = 0xcf.toByte(); p[41] = 0x08 // 53000
            p[42] = 0; p[43] = 53
            p[44] = (udpLength ushr 8).toByte(); p[45] = udpLength.toByte()
            dns.copyInto(p, 48)
        }
    }

    @Test fun parsesIpv6DnsAndBuildsChecksummedReverseResponse() {
        val queryPacket = ipv6Query()
        val query = Ipv6DnsPacketCodec.readQuery(queryPacket, queryPacket.size)!!
        assertEquals("www.example", LocalDnsPolicy.readQuestionName(query.dns))
        assertEquals(53000, query.sourcePort)

        val dnsResponse = query.dns.copyOf().also { it[2] = 0x81.toByte() }
        val response = Ipv6DnsPacketCodec.makeResponse(query, dnsResponse)!!
        assertEquals(6, response[0].toInt() ushr 4)
        assertEquals(17, response[6].toInt() and 0xff)
        assertEquals(53, u16(response, 40))
        assertEquals(53000, u16(response, 42))
        assertArrayEquals(queryPacket.copyOfRange(24, 40), response.copyOfRange(8, 24))
        assertArrayEquals(queryPacket.copyOfRange(8, 24), response.copyOfRange(24, 40))
        assertEquals(0xffff, udpChecksumIncludingChecksum(response))
    }

    @Test fun rejectsNonDnsUdpMalformedAndExtensionHeaderPackets() {
        val valid = ipv6Query()
        assertNull(Ipv6DnsPacketCodec.readQuery(valid, valid.size - 1))
        assertNull(Ipv6DnsPacketCodec.readQuery(valid.copyOf().also { it[43] = 54 }, valid.size))
        assertNull(Ipv6DnsPacketCodec.readQuery(valid.copyOf().also { it[6] = 0 }, valid.size))
        assertNull(Ipv6DnsPacketCodec.readQuery(valid.copyOf().also { it[45] = 1 }, valid.size))
    }

    @Test fun refusesResponseForDifferentDnsQuestion() {
        val packet = ipv6Query()
        val query = Ipv6DnsPacketCodec.readQuery(packet, packet.size)!!
        val wrong = query.dns.copyOf().also { it[13] = 'x'.code.toByte(); it[2] = 0x81.toByte() }
        assertNull(Ipv6DnsPacketCodec.makeResponse(query, wrong))
    }

    private fun u16(data: ByteArray, offset: Int) =
        ((data[offset].toInt() and 0xff) shl 8) or (data[offset + 1].toInt() and 0xff)

    /** Returns the folded one's-complement sum including the UDP checksum; valid is 0xffff. */
    private fun udpChecksumIncludingChecksum(packet: ByteArray): Int {
        val length = u16(packet, 4)
        var sum = 0L
        fun add(offset: Int, size: Int) {
            var i = offset
            while (i + 1 < offset + size) {
                sum += ((packet[i].toInt() and 0xff) shl 8) or (packet[i + 1].toInt() and 0xff)
                i += 2
            }
            if (i < offset + size) sum += (packet[i].toInt() and 0xff) shl 8
        }
        add(8, 32)
        sum += length.toLong()
        sum += 17L
        add(40, length)
        while (sum ushr 16 != 0L) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.toInt() and 0xffff
    }
}
