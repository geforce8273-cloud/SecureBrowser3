package de.deinname.securebrowse.jarvis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MemoryGuardTest {
    private val gb = 1024L * 1024L * 1024L
    private val mb = 1024L * 1024L

    @Test fun refusesModelLargerThan60PercentOfTotalRam() {
        val plan = MemoryGuard.plan(modelBytes = 5 * gb, totalRamBytes = 8 * gb, availableRamBytes = 6 * gb, lowMemoryThresholdBytes = 300 * mb)
        assertTrue(plan is MemoryGuard.Plan.Refused)
    }

    @Test fun refusesWhenFreeRamIsTooLow() {
        val plan = MemoryGuard.plan(modelBytes = 2 * gb, totalRamBytes = 6 * gb, availableRamBytes = 2 * gb, lowMemoryThresholdBytes = 300 * mb)
        assertTrue(plan is MemoryGuard.Plan.Refused)
    }

    @Test fun allowsSmallModelAndCapsKvBudget() {
        val plan = MemoryGuard.plan(modelBytes = 1 * gb, totalRamBytes = 8 * gb, availableRamBytes = 5 * gb, lowMemoryThresholdBytes = 300 * mb)
        assertTrue(plan is MemoryGuard.Plan.Allowed)
        assertEquals(768 * mb, (plan as MemoryGuard.Plan.Allowed).kvBudgetBytes)
    }

    @Test fun kvBudgetShrinksWithHeadroom() {
        val plan = MemoryGuard.plan(modelBytes = 1 * gb, totalRamBytes = 8 * gb, availableRamBytes = 1 * gb + 300 * mb + 256 * mb + 200 * mb, lowMemoryThresholdBytes = 300 * mb)
        assertEquals(200 * mb, (plan as MemoryGuard.Plan.Allowed).kvBudgetBytes)
    }
}
