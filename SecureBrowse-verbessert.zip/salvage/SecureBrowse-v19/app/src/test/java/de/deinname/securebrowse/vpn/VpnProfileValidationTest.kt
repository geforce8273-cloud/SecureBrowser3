package de.deinname.securebrowse.vpn

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VpnProfileValidationTest {
    @Test fun acceptsWireGuardProfile() {
        assertTrue(VpnProfileValidation.validate(
            EncryptedVpnProfileStore.Profile("Home", "[Interface]\\nPrivateKey = redacted", VpnType.WIREGUARD)
        ).isSuccess)
    }

    @Test fun acceptsOpenVpnProfile() {
        assertTrue(VpnProfileValidation.validate(
            EncryptedVpnProfileStore.Profile("Travel", "client\\nremote vpn.example 1194", VpnType.OPENVPN)
        ).isSuccess)
    }

    @Test fun rejectsBlankOrOversizedNames() {
        assertFalse(VpnProfileValidation.validate(
            EncryptedVpnProfileStore.Profile("  ", "valid config")
        ).isSuccess)
        assertFalse(VpnProfileValidation.validate(
            EncryptedVpnProfileStore.Profile("x".repeat(81), "valid config")
        ).isSuccess)
    }

    @Test fun rejectsControlCharactersAndEmptyConfigs() {
        assertFalse(VpnProfileValidation.validate(
            EncryptedVpnProfileStore.Profile("bad\\nname", "valid config")
        ).isSuccess)
        assertFalse(VpnProfileValidation.validate(
            EncryptedVpnProfileStore.Profile("valid", "  ")
        ).isSuccess)
    }

    @Test fun rejectsUnknownTypesAndOversizedConfigs() {
        assertFalse(VpnProfileValidation.validate(
            EncryptedVpnProfileStore.Profile("valid", "config", "unknown")
        ).isSuccess)
        assertFalse(VpnProfileValidation.validate(
            EncryptedVpnProfileStore.Profile("valid", "x".repeat(512 * 1024 + 1))
        ).isSuccess)
    }
}
