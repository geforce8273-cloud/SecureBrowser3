package de.deinname.securebrowse.core

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DiagnosticReportTest {
    @Test fun containsKeyFacts() {
        val r = DiagnosticReport.build("0.1.0", "14", 34, "arm64-v8a", 6000, 2500, "getrennt", "aus", listOf("E1"))
        assertTrue(r.contains("arm64-v8a") && r.contains("2500 MB frei von 6000 MB") && r.contains("E1"))
        assertFalse(r.contains("http"))
    }
}
