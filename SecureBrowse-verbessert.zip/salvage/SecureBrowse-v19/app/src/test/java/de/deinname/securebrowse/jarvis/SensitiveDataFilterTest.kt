package de.deinname.securebrowse.jarvis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SensitiveDataFilterTest {
    @Test fun detectsValidCardNumber() = assertTrue(SensitiveKind.CARD_NUMBER in SensitiveDataFilter.detect("Karte 4111 1111 1111 1111 merken"))
    @Test fun ignoresInvalidLuhn() = assertFalse(SensitiveKind.CARD_NUMBER in SensitiveDataFilter.detect("Nummer 4111 1111 1111 1112"))
    @Test fun detectsValidIban() = assertTrue(SensitiveKind.IBAN in SensitiveDataFilter.detect("IBAN DE89 3704 0044 0532 0130 00"))
    @Test fun ignoresInvalidIban() = assertFalse(SensitiveKind.IBAN in SensitiveDataFilter.detect("DE00 3704 0044 0532 0130 00"))
    @Test fun detectsPasswordHint() = assertTrue(SensitiveKind.PASSWORD_HINT in SensitiveDataFilter.detect("Passwort: geheim"))
    @Test fun normalNoteIsSafe() = assertTrue(SensitiveDataFilter.isSafeToStore("Morgen um 10 Uhr Zahnarzt, Telefon 030 1234567"))
    @Test fun emptyIsSafe() = assertEquals(emptySet<SensitiveKind>(), SensitiveDataFilter.detect(""))
}
