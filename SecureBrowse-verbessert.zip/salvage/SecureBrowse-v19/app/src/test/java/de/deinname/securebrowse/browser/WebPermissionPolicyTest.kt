package de.deinname.securebrowse.browser

import android.webkit.PermissionRequest
import org.junit.Assert.assertEquals
import org.junit.Test

class WebPermissionPolicyTest {
    @Test fun allowsCaptureOnlyForHttpsOrigin() {
        assertEquals(
            listOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE),
            WebPermissionPolicy.allowedResources(
                "https://camera.example/path",
                listOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE, "unknown-resource")
            )
        )
    }

    @Test fun rejectsInsecureOrMalformedOrigins() {
        val capture = listOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
        listOf("http://camera.example", "javascript:alert(1)", "https://user@camera.example", "not a URL")
            .forEach { assertEquals(emptyList<String>(), WebPermissionPolicy.allowedResources(it, capture)) }
    }

    @Test fun rejectsUnsupportedResourcesAndDeduplicates() {
        val video = PermissionRequest.RESOURCE_VIDEO_CAPTURE
        assertEquals(listOf(video), WebPermissionPolicy.allowedResources("https://camera.example", listOf(video, video, "unknown")))
    }
}
