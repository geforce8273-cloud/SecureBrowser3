package de.deinname.securebrowse.browser

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LinkToolsTest {
    @Test fun stripsTrackingKeepsRest() =
        assertEquals("https://a.de/p?x=1&y=2#frag",
            LinkTools.stripTrackingParameters("https://a.de/p?utm_source=n&x=1&fbclid=abc&y=2#frag"))

    @Test fun removesQuestionMarkWhenNothingLeft() =
        assertEquals("https://a.de/p", LinkTools.stripTrackingParameters("https://a.de/p?gclid=1&utm_campaign=2"))

    @Test fun doesNotReencodePercent() =
        assertEquals("https://a.de/a%20b?q=%C3%A4", LinkTools.stripTrackingParameters("https://a.de/a%20b?q=%C3%A4&fbclid=1"))

    @Test fun urlWithoutQueryUnchanged() =
        assertEquals("https://a.de/x", LinkTools.stripTrackingParameters("https://a.de/x"))

    @Test fun normalLinkIsNotSuspicious() = assertFalse(LinkTools.analyze("https://www.example.org/path?q=1").isSuspicious)

    @Test fun userinfoTrickIsFlagged() =
        assertTrue(LinkRisk.USERINFO in LinkTools.analyze("https://bank.de@evil.example/login").risks)

    @Test fun backslashTrickIsFlagged() =
        assertTrue(LinkRisk.BACKSLASH in LinkTools.analyze("https://bank.de\\@evil.example").risks)

    @Test fun ipHostIsFlagged() = assertTrue(LinkRisk.IP_HOST in LinkTools.analyze("http://192.168.1.5/").risks)

    @Test fun punycodeIsFlagged() = assertTrue(LinkRisk.PUNYCODE in LinkTools.analyze("https://xn--bcher-kva.de/").risks)

    @Test fun unicodeHostIsFlagged() = assertTrue(LinkRisk.PUNYCODE in LinkTools.analyze("https://bücher.de/").risks)

    @Test fun oddPortIsFlagged() = assertTrue(LinkRisk.UNUSUAL_PORT in LinkTools.analyze("https://a.de:9999/").risks)

    @Test fun javascriptSchemeIsFlagged() = assertTrue(LinkRisk.UNUSUAL_SCHEME in LinkTools.analyze("javascript:alert(1)").risks)
}

class UrlToolsTrackingTest {
    @Test fun typedUrlLosesTrackingParams() =
        assertEquals("https://a.de/p?x=1", UrlTools.resolve("https://a.de/p?utm_source=n&x=1&fbclid=z", "https://d.example/?q=%s"))
}
