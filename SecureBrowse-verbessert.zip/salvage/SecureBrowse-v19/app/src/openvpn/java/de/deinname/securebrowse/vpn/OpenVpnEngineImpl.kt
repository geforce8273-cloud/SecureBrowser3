package de.deinname.securebrowse.vpn

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import de.blinkt.openvpn.VpnProfile
import de.blinkt.openvpn.core.ConfigParser
import de.blinkt.openvpn.core.OpenVPNService
import de.blinkt.openvpn.core.ProfileManager
import de.blinkt.openvpn.core.VPNLaunchHelper
import de.blinkt.openvpn.core.VpnStatus
import java.io.StringReader

/**
 * Glue zur eingebetteten ics-openvpn-Engine (GPLv2). Wird nur kompiliert, wenn
 * third_party/ics-openvpn vorhanden ist. PRUEFEN: Klassen-/Methodennamen gegen die
 * gepinnte ics-openvpn-Version abgleichen, sie ändern sich zwischen Releases.
 *
 * Datenschutz: ics-openvpn legt Profile unverschlüsselt in eigenen Dateien ab. Deshalb wird das
 * Profil nach dem Trennen sofort wieder entfernt; dauerhaft liegt es nur im verschlüsselten Store.
 */
class OpenVpnEngineImpl(private val context: Context) : OpenVpnEngine {
    private var active: VpnProfile? = null

    override fun connect(profileName: String, raw: String) {
        val parser = ConfigParser()
        parser.parseConfig(StringReader(raw))
        val profile = parser.convertProfile()
        profile.mName = profileName
        val manager = ProfileManager.getInstance(context)
        manager.addProfile(profile)
        manager.saveProfile(context, profile)
        active = profile
        VPNLaunchHelper.startOpenVpn(profile, context, "SecureBrowse", true)
    }

    override fun disconnect() {
        val connection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                (binder as? OpenVPNService.LocalBinder)?.service?.stopVPN(false)
                runCatching { context.unbindService(this) }
                removeStoredProfile()
            }
            override fun onServiceDisconnected(name: ComponentName?) = Unit
        }
        val intent = Intent(context, OpenVPNService::class.java).setAction(OpenVPNService.START_SERVICE)
        if (!context.bindService(intent, connection, Context.BIND_AUTO_CREATE)) removeStoredProfile()
    }

    override fun isConnected(): Boolean = VpnStatus.isVPNActive()

    private fun removeStoredProfile() {
        val profile = active ?: return
        runCatching { ProfileManager.getInstance(context).removeProfile(context, profile) }
        active = null
    }
}
