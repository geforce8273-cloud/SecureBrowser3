package de.deinname.securebrowse.browser

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.URLUtil

/** Hands a confirmed download to the system DownloadManager (saved in the public Downloads folder). */
object Downloads {

    fun fileName(d: PendingDialog.Download): String =
        URLUtil.guessFileName(d.url, d.contentDisposition, d.mimeType.ifBlank { null })

    /** Returns true if the system accepted the download. */
    fun enqueue(context: Context, d: PendingDialog.Download): Boolean = runCatching {
        val request = DownloadManager.Request(Uri.parse(d.url))
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName(d))
        if (d.mimeType.isNotBlank()) request.setMimeType(d.mimeType)
        if (d.userAgent.isNotBlank()) request.addRequestHeader("User-Agent", d.userAgent)
        CookieManager.getInstance().getCookie(d.url)?.let { request.addRequestHeader("Cookie", it) }
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        manager.enqueue(request)
    }.isSuccess
}
