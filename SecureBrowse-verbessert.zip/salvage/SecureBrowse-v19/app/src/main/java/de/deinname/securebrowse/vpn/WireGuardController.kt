package de.deinname.securebrowse.vpn

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.BufferedReader
import java.io.StringReader

/** Thin controller around the official WireGuard Android tunnel backend. */
class WireGuardController(context: Context) : VpnBackend {
    private val backend = GoBackend(context.applicationContext)
    private val tunnel = object : Tunnel {
        override fun getName(): String = TUNNEL_NAME
        override fun onStateChange(newState: Tunnel.State) = Unit
    }

    fun parseConfig(raw: String): Config = Config.parse(BufferedReader(StringReader(raw)))

    override fun validate(raw: String): Result<Unit> = runCatching { parseConfig(raw); Unit }

    override fun connect(profileName: String, raw: String) {
        val config = parseConfig(raw)
        backend.setState(tunnel, Tunnel.State.UP, config)
    }

    override fun disconnect() {
        backend.setState(tunnel, Tunnel.State.DOWN, null)
    }

    override fun isConnected(): Boolean = runCatching { backend.getState(tunnel) == Tunnel.State.UP }.getOrDefault(false)

    fun backendVersion(): String = runCatching { backend.version }.getOrDefault("WireGuard")

    companion object { private const val TUNNEL_NAME = "SecureBrowse" }
}
