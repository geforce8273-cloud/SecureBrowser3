package de.deinname.securebrowse.shield

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.ConnectivityManager
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.content.pm.ServiceInfo
import de.deinname.securebrowse.MainActivity
import de.deinname.securebrowse.R
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * On-device DNS filtering VPN. This is NOT an IP-masking VPN and has no VPN gateway.
 * Only DNS packets addressed to the local tunnel DNS address are intercepted.
 * Allowed DNS questions are forwarded to the resolver supplied by an active non-VPN
 * Android network. Strict Android Private DNS is forwarded over TLS (DoT) without a
 * plaintext downgrade; otherwise the network resolver is used over UDP. Blocked names
 * receive a local NXDOMAIN response.
 */
class LocalShieldVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private val stopping = AtomicBoolean(false)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopShield()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (tun == null) startTunnel()
        return START_STICKY
    }

    private fun startAsForeground() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "SecureBrowse Shield", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("SecureBrowse Shield aktiv")
            .setContentText("Lokaler DNS- und Trackerfilter läuft auf diesem Gerät")
            .setContentIntent(openApp)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startTunnel() {
        val descriptor = Builder()
            .setSession("SecureBrowse Shield · lokaler DNS-Filter")
            .setMtu(1500)
            .addAddress(TUN_ADDRESS, 32)
            .addDnsServer(DNS_ADDRESS)
            .addRoute(DNS_ADDRESS, 32)
            // Route only the private IPv6 DNS endpoint through this tunnel; other IPv6 traffic
            // remains on Android's normal network path.
            .addAddress(TUN_IPV6_ADDRESS, 128)
            .addDnsServer(DNS_IPV6_ADDRESS)
            .addRoute(DNS_IPV6_ADDRESS, 128)
            .setBlocking(true)
            .establish()
        if (descriptor == null) {
            stopShield()
            return
        }
        tun = descriptor
        stopping.set(false)
        isRunning = true
        worker = thread(name = "SecureBrowse-DNS-Shield", isDaemon = true) {
            runPacketLoop(descriptor)
        }
    }

    private fun runPacketLoop(descriptor: ParcelFileDescriptor) {
        val input = FileInputStream(descriptor.fileDescriptor)
        val output = FileOutputStream(descriptor.fileDescriptor)
        val packet = ByteArray(32767)
        while (!stopping.get()) {
            val count = try { input.read(packet) } catch (_: Exception) { break }
            if (count <= 0) continue
            try {
                val response = when (packet[0].toInt() ushr 4 and 0x0f) {
                    4 -> handleIpv4UdpDns(packet, count)
                    6 -> handleIpv6UdpDns(packet, count)
                    else -> null
                }
                if (response != null) output.write(response)
            } catch (_: Exception) {
                // Malformed/unsupported packets are ignored; never crash the VPN process.
            }
        }
    }

    private fun handleIpv4UdpDns(packet: ByteArray, length: Int): ByteArray? {
        if (length < 28 || (packet[0].toInt() ushr 4 and 0x0f) != 4) return null
        val ipHeaderLength = (packet[0].toInt() and 0x0f) * 4
        if (ipHeaderLength < 20 || length < ipHeaderLength + 8) return null
        if ((packet[9].toInt() and 0xff) != 17) return null // UDP only
        val fragmentField = u16(packet, 6)
        if ((fragmentField and 0x3fff) != 0) return null // no fragmented DNS packets
        val ipTotalLength = u16(packet, 2)
        if (ipTotalLength < ipHeaderLength + 8 || ipTotalLength > length) return null
        val udpOffset = ipHeaderLength
        val sourcePort = u16(packet, udpOffset)
        val destinationPort = u16(packet, udpOffset + 2)
        if (destinationPort != 53) return null
        val udpLength = u16(packet, udpOffset + 4)
        if (sourcePort == 0 || udpLength < 8 || udpOffset + udpLength > ipTotalLength) return null
        val dnsOffset = udpOffset + 8
        val dnsLength = udpLength - 8
        if (dnsLength < 17) return null
        val query = packet.copyOfRange(dnsOffset, dnsOffset + dnsLength)
        val domain = LocalDnsPolicy.readQuestionName(query) ?: return null
        val dnsResponse = if (LocalDnsPolicy.isBlocked(domain)) {
            LocalDnsPolicy.makeNxDomain(query)
        } else {
            val upstream = currentNetworkDns() ?: return null
            forwardDns(query, upstream)
        } ?: return null
        return makeIpv4UdpResponse(packet, sourcePort, destinationPort, dnsResponse)
    }

    private fun handleIpv6UdpDns(packet: ByteArray, length: Int): ByteArray? {
        val query = Ipv6DnsPacketCodec.readQuery(packet, length) ?: return null
        val domain = LocalDnsPolicy.readQuestionName(query.dns) ?: return null
        val dnsResponse = if (LocalDnsPolicy.isBlocked(domain)) {
            LocalDnsPolicy.makeNxDomain(query.dns)
        } else {
            val upstream = currentNetworkDns() ?: return null
            forwardDns(query.dns, upstream)
        } ?: return null
        return Ipv6DnsPacketCodec.makeResponse(query, dnsResponse)
    }

    private data class DnsUpstream(val address: InetAddress, val tlsHostname: String?)

    private fun currentNetworkDns(): DnsUpstream? = runCatching {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        // Do not select this VPN's own virtual interface as upstream DNS.
        cm.allNetworks.asSequence()
            .filter { network ->
                val capabilities = cm.getNetworkCapabilities(network) ?: return@filter false
                capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_VPN) &&
                    !capabilities.hasTransport(android.net.NetworkCapabilities.TRANSPORT_VPN)
            }
            .sortedByDescending { network ->
                cm.getNetworkCapabilities(network)?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
            }
            .mapNotNull { network ->
                val links = cm.getLinkProperties(network) ?: return@mapNotNull null
                val address = links.dnsServers.firstOrNull() ?: return@mapNotNull null
                val strictPrivateDnsHost = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && links.isPrivateDnsActive) {
                    links.privateDnsServerName?.takeIf { it.isNotBlank() }
                } else null
                DnsUpstream(address, strictPrivateDnsHost)
            }
            .firstOrNull()
    }.getOrNull()

    private fun forwardDns(query: ByteArray, upstream: DnsUpstream): ByteArray? =
        if (upstream.tlsHostname != null) {
            // Strict Android Private DNS: never downgrade this request to plaintext UDP.
            forwardDnsOverTls(query, upstream.address, upstream.tlsHostname)
        } else {
            forwardDnsUdp(query, upstream.address)
        }

    private fun forwardDnsUdp(query: ByteArray, resolver: InetAddress): ByteArray? = runCatching {
        DatagramSocket().use { socket ->
            if (!protect(socket)) return null
            socket.soTimeout = 3500
            socket.connect(resolver, 53)
            val outgoing = DatagramPacket(query, query.size, resolver, 53)
            socket.send(outgoing)
            val buffer = ByteArray(4096)
            val incoming = DatagramPacket(buffer, buffer.size)
            socket.receive(incoming)
            if (incoming.length < 12) return null
            val response = buffer.copyOf(incoming.length)
            if (!LocalDnsPolicy.isMatchingResponse(query, response)) return null
            response
        }
    }.getOrNull()

    private fun forwardDnsOverTls(query: ByteArray, resolver: InetAddress, hostname: String): ByteArray? = runCatching {
        val rawSocket = Socket()
        if (!protect(rawSocket)) {
            rawSocket.close()
            return null
        }
        rawSocket.connect(InetSocketAddress(resolver, 853), 3500)
        val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
        (factory.createSocket(rawSocket, hostname, 853, true) as SSLSocket).use { tls ->
            tls.soTimeout = 3500
            tls.sslParameters = tls.sslParameters.apply { endpointIdentificationAlgorithm = "HTTPS" }
            tls.startHandshake()
            val output = DataOutputStream(tls.outputStream)
            output.writeShort(query.size)
            output.write(query)
            output.flush()
            val input = DataInputStream(tls.inputStream)
            val responseLength = input.readUnsignedShort()
            if (responseLength < 12 || responseLength > 4096) return null
            val response = ByteArray(responseLength)
            input.readFully(response)
            if (!LocalDnsPolicy.isMatchingResponse(query, response)) return null
            response
        }
    }.getOrNull()

    private fun makeIpv4UdpResponse(
        request: ByteArray, sourcePort: Int, destinationPort: Int, dns: ByteArray
    ): ByteArray {
        val udpLength = 8 + dns.size
        val result = ByteArray(20 + udpLength)
        result[0] = 0x45
        result[1] = 0
        put16(result, 2, result.size)
        result[8] = 64
        result[9] = 17
        // Reply source is the DNS address the Android resolver queried; destination is the client.
        request.copyOfRange(16, 20).copyInto(result, 12)
        request.copyOfRange(12, 16).copyInto(result, 16)
        put16(result, 10, checksum(result, 0, 20))
        put16(result, 20, destinationPort)
        put16(result, 22, sourcePort)
        put16(result, 24, udpLength)
        dns.copyInto(result, 28)
        // UDP checksum zero is permitted for IPv4.
        return result
    }

    private fun checksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        while (i + 1 < offset + length) {
            sum += ((data[i].toInt() and 0xff) shl 8) or (data[i + 1].toInt() and 0xff)
            i += 2
        }
        if (i < offset + length) sum += (data[i].toInt() and 0xff) shl 8
        while (sum ushr 16 != 0L) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.inv().toInt() and 0xffff
    }

    private fun u16(data: ByteArray, offset: Int): Int =
        ((data[offset].toInt() and 0xff) shl 8) or (data[offset + 1].toInt() and 0xff)

    private fun put16(data: ByteArray, offset: Int, value: Int) {
        data[offset] = (value ushr 8).toByte()
        data[offset + 1] = value.toByte()
    }

    private fun stopShield() {
        stopping.set(true)
        isRunning = false
        runCatching { tun?.close() }
        tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        stopShield()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopShield()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "de.deinname.securebrowse.shield.START"
        const val ACTION_STOP = "de.deinname.securebrowse.shield.STOP"
        private const val CHANNEL_ID = "securebrowse_local_shield"
        private const val NOTIFICATION_ID = 7012
        private const val TUN_ADDRESS = "10.77.0.1"
        private const val DNS_ADDRESS = "10.77.0.2"
        private const val TUN_IPV6_ADDRESS = "fd77:77::1"
        private const val DNS_IPV6_ADDRESS = "fd77:77::2"
        @Volatile var isRunning: Boolean = false
            private set

        // Small built-in starter list. The app's WebView filter remains active too.
    }
}
