package de.deinname.securebrowse.jarvis

/** Pure GGUF header sanity checks (no Android dependencies, unit-testable). */
object GgufHeader {
    const val HEADER_BYTES = 24L
    // Lower bounds per entry: metadata KV = 8 (key length) + 1 (key) + 4 (type); tensor info = 8 + 1 + 4 + 8 + 4 + 8.
    private const val MIN_METADATA_ENTRY_BYTES = 13L
    private const val MIN_TENSOR_ENTRY_BYTES = 33L

    /** Returns an error message or null when the header values are plausible for [fileLength]. */
    fun validate(fileLength: Long, version: Long, tensors: Long, metadata: Long): String? {
        if (fileLength < HEADER_BYTES) return "Datei ist zu klein und kein gültiges GGUF-Modell."
        if (version !in 2L..3L) return "Nicht unterstützte GGUF-Version: $version"
        if (tensors !in 1L..10_000_000L || metadata !in 1L..1_000_000L) return "GGUF-Kopfzeile enthält ungültige Werte."
        val minimum = HEADER_BYTES + metadata * MIN_METADATA_ENTRY_BYTES + tensors * MIN_TENSOR_ENTRY_BYTES
        if (fileLength < minimum) return "GGUF-Datei ist abgeschnitten oder beschädigt."
        return null
    }
}
