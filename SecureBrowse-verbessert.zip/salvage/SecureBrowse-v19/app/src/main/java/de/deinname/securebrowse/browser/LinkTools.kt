package de.deinname.securebrowse.browser

import java.net.IDN
import java.net.URI
import java.util.Locale

/** Gruende fuer eine Link-Warnung. Reine Codes: die UI uebersetzt sie (EN/DE), die Regeln entscheiden. */
enum class LinkRisk { INVALID_URL, UNUSUAL_SCHEME, USERINFO, BACKSLASH, NO_HOST, PUNYCODE, IP_HOST, MANY_SUBDOMAINS, UNUSUAL_PORT, INVALID_PORT }

data class LinkSafetyResult(val risks: List<LinkRisk>) {
    val isSuspicious: Boolean get() = risks.isNotEmpty()
}

/** Reines Kotlin (JVM-testbar), wirft nie. Arbeitet offline, ohne Netzwerk. */
object LinkTools {

    val TRACKING_PARAMS: Set<String> = setOf(
        "fbclid", "gclid", "dclid", "msclkid", "mc_eid", "mc_cid", "yclid", "twclid", "igshid",
        "_hsenc", "_hsmi", "rb_clickid", "vero_id"
    )

    private val ipv4 = Regex("^(\\d{1,3}\\.){3}\\d{1,3}$")
    private val commonPorts = setOf(80, 443, 8080, 8443)

    private fun isTracking(key: String): Boolean {
        val k = key.lowercase(Locale.ROOT)
        return k.startsWith("utm_") || k in TRACKING_PARAMS
    }

    /** Entfernt Tracking-Parameter. Der Rest der URL bleibt Zeichen fuer Zeichen unveraendert (keine Neu-Kodierung). */
    fun stripTrackingParameters(url: String): String {
        val hash = url.indexOf('#')
        val fragment = if (hash >= 0) url.substring(hash) else ""
        val noFragment = if (hash >= 0) url.substring(0, hash) else url
        val q = noFragment.indexOf('?')
        if (q < 0) return url
        val base = noFragment.substring(0, q)
        val kept = noFragment.substring(q + 1).split('&').filter { it.isNotEmpty() && !isTracking(it.substringBefore('=')) }
        return base + (if (kept.isEmpty()) "" else "?" + kept.joinToString("&")) + fragment
    }

    fun analyze(url: String): LinkSafetyResult {
        val risks = linkedSetOf<LinkRisk>()
        val text = url.trim()
        if (text.contains('\\')) risks += LinkRisk.BACKSLASH
        val uri = try { URI(text) } catch (_: Exception) {
            risks += LinkRisk.INVALID_URL
            return LinkSafetyResult(risks.toList())
        }
        val scheme = uri.scheme?.lowercase(Locale.ROOT).orEmpty()
        if (scheme != "http" && scheme != "https") risks += LinkRisk.UNUSUAL_SCHEME

        val authority = uri.rawAuthority.orEmpty()
        if (authority.contains('@')) risks += LinkRisk.USERINFO

        // URI.getHost() ist bei Nicht-ASCII-Namen null: dann den Host selbst aus der Autoritaet lesen.
        val hostPart = authority.substringAfterLast('@')
        val host = (uri.host ?: if (hostPart.startsWith("[")) hostPart else hostPart.substringBeforeLast(':', hostPart))
            .lowercase(Locale.ROOT)
        if (host.isEmpty()) {
            risks += LinkRisk.NO_HOST
        } else {
            val ascii = try { IDN.toASCII(host) } catch (_: Exception) { host }
            if (ascii.startsWith("xn--") || ascii.contains(".xn--") || host.any { it.code > 127 }) risks += LinkRisk.PUNYCODE
            if (ipv4.matches(host) || host.startsWith("[")) risks += LinkRisk.IP_HOST
            if (host.count { it == '.' } >= 4) risks += LinkRisk.MANY_SUBDOMAINS
        }

        val port = uri.port
        if (port != -1 && port !in commonPorts) {
            risks += if (port in 1..65535) LinkRisk.UNUSUAL_PORT else LinkRisk.INVALID_PORT
        }
        return LinkSafetyResult(risks.toList())
    }
}
