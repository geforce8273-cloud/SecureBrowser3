package de.deinname.securebrowse.ui

import android.content.Intent
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.HorizontalDivider
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.vector.ImageVector
import de.deinname.securebrowse.browser.BrowserUiState
import androidx.activity.compose.LocalActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Badge
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import de.deinname.securebrowse.R
import de.deinname.securebrowse.browser.BrowserViewModel
import de.deinname.securebrowse.browser.TabUi
import de.deinname.securebrowse.browser.UrlTools
import de.deinname.securebrowse.tor.TorModePolicy
import de.deinname.securebrowse.browser.WebViewRegistry
import de.deinname.securebrowse.data.SearchEngines
import de.deinname.securebrowse.jarvis.JarvisController

@Composable
fun BrowserScreen(
    viewModel: BrowserViewModel,
    registry: WebViewRegistry,
    onOpenTabs: () -> Unit,
    onOpenBookmarks: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenVpn: () -> Unit,
    onOpenJarvis: () -> Unit,
    jarvisController: JarvisController,
    vpnConnected: () -> Boolean = { false }
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val bookmarks by viewModel.bookmarks.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var menuOpen by remember { mutableStateOf(false) }
    var searchDialog by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var vpnOn by remember { mutableStateOf(false) }
    var jarvisEnabled by remember { mutableStateOf(jarvisController.isEnabled()) }
    SoundFx.init(context)
    var soundOn by remember { mutableStateOf(SoundFx.enabled) }
    var glowOn by remember { mutableStateOf(SoundFx.glow) }
    var desktopOn by remember { mutableStateOf(registry.desktopMode) }
    LaunchedEffect(Unit) { vpnOn = vpnConnected() }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        vpnOn = vpnConnected()
        jarvisEnabled = jarvisController.isEnabled()
    }

    val tab = state.selectedTab

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(context.getString(it))
            viewModel.messageShown()
        }
    }

    LaunchedEffect(state.allowMixedContent) { registry.setMixedContentAllowed(state.allowMixedContent) }

    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { tab?.let { registry.peek(it.id)?.onPause() } }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tab?.let { registry.peek(it.id)?.onResume() } }

    // Back: leave fullscreen first, then navigate within the page. Otherwise the system handles it.
    BackHandler(enabled = state.customView != null) { registry.exitFullscreen() }
    BackHandler(enabled = state.customView == null && tab?.canGoBack == true) {
        tab?.let { registry.peek(it.id)?.goBack() }
    }
    // Erste Seite eines Tabs: Tab schließen und zum vorherigen Tab wechseln (App bleibt offen).
    BackHandler(enabled = state.customView == null && tab?.canGoBack != true && state.tabs.size > 1) {
        viewModel.closeCurrentAndGoToPrevious()?.let { registry.remove(it) }
    }
    // Nur ein Tab übrig: zweimal Zurück innerhalb von 2 s beendet die App.
    var lastBackAt by remember { mutableStateOf(0L) }
    BackHandler(enabled = state.customView == null && tab?.canGoBack != true && state.tabs.size <= 1) {
        val now = System.currentTimeMillis()
        if (now - lastBackAt < 2000L) {
            (context as? android.app.Activity)?.finish()
        } else {
            lastBackAt = now
            viewModel.showMessage(R.string.press_back_again)
        }
    }

    val chromeHidden by registry.chromeHidden.collectAsStateWithLifecycle()
    // Bei neuer Seite oder anderem Tab die Leisten wieder einblenden
    LaunchedEffect(tab?.id, tab?.url) { registry.showChrome() }
    val barsHidden = chromeHidden && tab != null && tab.url.isNotBlank()

    Box(Modifier.fillMaxSize()) {
        if (state.torMode) TorAnimatedBackground(Modifier.fillMaxSize())
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbar) },
            contentWindowInsets = WindowInsets.safeDrawing
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                if (!state.loaded || tab == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                } else {
                    AnimatedVisibility(
                        visible = !barsHidden,
                        enter = expandVertically(tween(260)) + fadeIn(tween(260)),
                        exit = shrinkVertically(tween(260)) + fadeOut(tween(200))
                    ) {
                    Column {
                    AddressBar(
                        tab = tab,
                        tabCount = state.tabs.size,
                        onSubmit = { input ->
                            val resolved = viewModel.resolveNavigationInput(input)
                            if (resolved == null) viewModel.showMessage(R.string.invalid_address)
                            else if (state.torMode && !TorModePolicy().canLoad(state.torState)) viewModel.showMessage(R.string.tor_engine_missing)
                            else registry.load(tab.id, resolved.url)
                        },
                        onOpenTabs = onOpenTabs,
                        vpnOn = vpnOn,
                        onOpenVpn = onOpenVpn
                    )
                    AnimatedVisibility(visible = state.tabs.size > 1, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                    TabStrip(
                        tabs = state.tabs,
                        selectedId = tab.id,
                        onSelect = viewModel::selectTab,
                        onClose = { id -> registry.remove(id); viewModel.closeTab(id) },
                        onNew = { viewModel.newTab() }
                    )
                    }
                    }
                    }
                    if (tab.isLoading) {
                        GradientProgress(progress = tab.progress / 100f)
                    } else {
                        Spacer(Modifier.height(2.dp))
                    }
                    if (tab.sslError) {
                        Surface(color = MaterialTheme.colorScheme.errorContainer, modifier = Modifier.fillMaxWidth()) {
                            Text(
                                stringResource(R.string.cert_error_banner),
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        if (state.torMode && !TorModePolicy().canLoad(state.torState)) {
                            TorBlockedNotice()
                        } else if (tab.url.isBlank()) {
                            StartPage(onOpen = { url -> registry.load(tab.id, url) })
                        } else {
                            key(tab.id, tab.generation) {
                                AndroidView(
                                    modifier = Modifier.fillMaxSize(),
                                    factory = {
                                        registry.getOrCreate(tab.id, tab.url).also { view ->
                                            (view.parent as? ViewGroup)?.removeView(view)
                                        }
                                    },
                                    onRelease = { view -> (view.parent as? ViewGroup)?.removeView(view) }
                                )
                            }
                        }
                    }
                    AnimatedVisibility(
                        visible = !barsHidden,
                        enter = expandVertically(tween(260)) + fadeIn(tween(260)),
                        exit = shrinkVertically(tween(260)) + fadeOut(tween(200))
                    ) {
                    Column {
                    TorToggleBar(torOn = state.torMode, torState = state.torState, onToggle = viewModel::setTorMode)
                    BottomNav(
                        vpnOn = vpnOn,
                        onStart = { if (tab.url.isNotBlank()) viewModel.newTab() },
                        onBookmarks = onOpenBookmarks,
                        onHistory = onOpenHistory,
                        onVpn = onOpenVpn,
                        onJarvis = onOpenJarvis,
                        onSettings = { settingsOpen = true }
                    )
                    }
                    }
                }
            }
        }

        state.customView?.let { FullscreenOverlay(it, onExit = registry::exitFullscreen) }
    }

    if (searchDialog) {
        AlertDialog(
            onDismissRequest = { searchDialog = false },
            title = { Text(stringResource(R.string.search_engine)) },
            text = {
                Column {
                    SearchEngines.all.forEach { engine ->
                        Row(
                            Modifier.fillMaxWidth().height(48.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = engine.id == state.searchEngine.id,
                                onClick = { viewModel.setSearchEngine(engine.id); searchDialog = false }
                            )
                            Text(engine.name)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { searchDialog = false }) { Text(stringResource(R.string.close)) } }
        )
    }

    if (settingsOpen && tab != null) {
        SettingsSheet(
            state = state,
            tab = tab,
            bookmarked = bookmarks.any { it.url == tab.url },
            onDismiss = { settingsOpen = false },
            onThemeMode = viewModel::setThemeMode,
            onReload = { settingsOpen = false; registry.peek(tab.id)?.reload() },
            onToggleBookmark = { settingsOpen = false; viewModel.toggleBookmark() },
            onShare = { settingsOpen = false; shareLink(context, tab.url) },
            onSearchEngine = { settingsOpen = false; searchDialog = true },
            onToggleMixed = {
                val allowed = !state.allowMixedContent
                registry.setMixedContentAllowed(allowed)
                viewModel.setAllowMixedContent(allowed)
                registry.peek(tab.id)?.reload()
            },
            onClearHistory = { settingsOpen = false; viewModel.clearHistory() },
            soundOn = soundOn,
            onSoundToggle = { soundOn = !soundOn; SoundFx.setEnabled(context, soundOn); if (soundOn) SoundFx.play() },
            glowOn = glowOn,
            onGlowToggle = { glowOn = !glowOn; SoundFx.setGlow(context, glowOn) },
            desktopOn = desktopOn,
            onDesktopToggle = {
                desktopOn = !desktopOn
                registry.setDesktopMode(desktopOn)
                registry.peek(tab.id)?.reload()
            },
            jarvisEnabled = jarvisEnabled,
            onJarvisEnabledChange = { enabled ->
                jarvisController.setEnabled(enabled)
                jarvisEnabled = enabled
            }
        )
    }

    BrowserDialogs(state = state, viewModel = viewModel)
}

@Composable
private fun AddressBar(
    tab: TabUi,
    tabCount: Int,
    onSubmit: (String) -> Unit,
    onOpenTabs: () -> Unit,
    vpnOn: Boolean,
    onOpenVpn: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    var focused by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current
    SoundFx.init(LocalContext.current)
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val glass = if (dark) Color.White.copy(alpha = 0.09f) else Color.White.copy(alpha = 0.72f)
    val borderColor by animateColorAsState(
        if (focused) Brand.Violet else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
        animationSpec = tween(250), label = "addrBorder"
    )
    val borderWidth by animateDpAsState(if (focused) 1.5.dp else 1.dp, tween(250), label = "addrBorderW")
    val shown = if (focused) text else tab.url

    Row(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = glass,
            border = BorderStroke(borderWidth, borderColor),
            modifier = Modifier.weight(1f).height(40.dp)
        ) {
            Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                SecurityIcon(tab)
                Spacer(Modifier.width(8.dp))
                BasicTextField(
                    value = shown,
                    onValueChange = { if (it.length != text.length) SoundFx.play(); text = it },
                    modifier = Modifier.weight(1f).onFocusChanged {
                        if (it.isFocused && !focused) text = tab.url
                        focused = it.isFocused
                    },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface),
                    cursorBrush = SolidColor(Brand.Violet),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = {
                        SoundFx.play()
                        focusManager.clearFocus()
                        onSubmit(text)
                    }),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (shown.isEmpty()) {
                                Text(
                                    stringResource(R.string.address_hint),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                    maxLines = 1
                                )
                            }
                            inner()
                        }
                    }
                )
            }
        }
        Surface(
            onClick = onOpenVpn,
            shape = RoundedCornerShape(20.dp),
            color = glass,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
            modifier = Modifier.height(40.dp).tapFx(20.dp)
        ) {
            Row(Modifier.padding(horizontal = 12.dp).height(40.dp), verticalAlignment = Alignment.CenterVertically) {
                val dot by animateColorAsState(
                    if (vpnOn) Brand.Violet else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    animationSpec = tween(300), label = "vpnDot"
                )
                val dotScale by animateFloatAsState(if (vpnOn) 1.2f else 1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "vpnDotScale")
                Box(Modifier.size(8.dp).graphicsLayer { scaleX = dotScale; scaleY = dotScale }.clip(CircleShape).background(dot))
                Spacer(Modifier.width(6.dp))
                Text(if (vpnOn) "VPN an" else "VPN aus", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SecurityIcon(tab: TabUi) {
    when {
        tab.sslError -> Icon(
            Icons.Filled.Warning, stringResource(R.string.status_cert_error),
            tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp)
        )
        UrlTools.isHttps(tab.url) -> Icon(
            Icons.Filled.Lock, stringResource(R.string.status_https),
            tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp)
        )
        UrlTools.isHttp(tab.url) -> Icon(
            Icons.Filled.Warning, stringResource(R.string.status_http),
            tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp)
        )
        else -> Icon(
            Icons.Filled.Search, stringResource(R.string.status_empty),
            tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
private fun BottomBar(
    tab: TabUi,
    bookmarked: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onReloadOrStop: () -> Unit,
    onToggleBookmark: () -> Unit,
    menu: @Composable () -> Unit
) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, enabled = tab.canGoBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back))
            }
            IconButton(onClick = onForward, enabled = tab.canGoForward) {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, stringResource(R.string.forward))
            }
            IconButton(onClick = onReloadOrStop, enabled = tab.url.isNotBlank()) {
                if (tab.isLoading) Icon(Icons.Filled.Close, stringResource(R.string.stop))
                else Icon(Icons.Filled.Refresh, stringResource(R.string.reload))
            }
            IconButton(onClick = onToggleBookmark, enabled = UrlTools.isWebUrl(tab.url)) {
                Icon(
                    if (bookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                    stringResource(if (bookmarked) R.string.bookmark_remove else R.string.bookmark_add)
                )
            }
            Box { menu() }
        }
    }
}

@Composable
private fun StartPage(onOpen: (String) -> Unit) {
    val tiles = listOf(
        Triple("DuckDuckGo", "D", "https://duckduckgo.com"),
        Triple("Wikipedia", "W", "https://de.wikipedia.org"),
        Triple("Tagesschau", "T", "https://www.tagesschau.de"),
        Triple("Neverssl", "N", "http://neverssl.com")
    )
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val glass = if (dark) Color.White.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.65f)
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val headAlpha by animateFloatAsState(if (shown) 1f else 0f, tween(600), label = "headAlpha")
    val float = rememberInfiniteTransition(label = "tileFloat")
    val bob by float.animateFloat(
        initialValue = -3f, targetValue = 3f,
        animationSpec = infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob"
    )
    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer { alpha = headAlpha; translationY = (1f - headAlpha) * 48f }
        ) {
            BrandOrb()
            Spacer(Modifier.height(18.dp))
            Text(
                "Privat surfen,\nohne Umwege.",
                style = MaterialTheme.typography.headlineMedium.copy(brush = Brand.accent),
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Adresse oder Suchbegriff eingeben. Tracker bleiben draußen.",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(32.dp))
        tiles.chunked(2).forEachIndexed { row, pair ->
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEachIndexed { col, (name, letter, url) ->
                    val index = row * 2 + col
                    val tileAlpha by animateFloatAsState(
                        if (shown) 1f else 0f, tween(450, delayMillis = 200 + index * 110), label = "tileAlpha"
                    )
                    val offset = if (index % 2 == 0) bob else -bob
                    Surface(
                        onClick = { onOpen(url) },
                        shape = RoundedCornerShape(22.dp),
                        color = glass,
                        border = BorderStroke(1.dp, Brand.Violet.copy(alpha = 0.22f)),
                        modifier = Modifier.weight(1f).graphicsLayer {
                            alpha = tileAlpha
                            translationY = (1f - tileAlpha) * 40f + offset
                        }.tapFx(22.dp)
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(40.dp).clip(RoundedCornerShape(14.dp)).background(Brand.accent),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(letter, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(name, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TabStrip(
    tabs: List<TabUi>,
    selectedId: Long,
    onSelect: (Long) -> Unit,
    onClose: (Long) -> Unit,
    onNew: () -> Unit
) {
    LazyRow(
        modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
        contentPadding = PaddingValues(horizontal = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items(tabs, key = { it.id }) { t ->
            val selected = t.id == selectedId
            val label = t.title.ifBlank {
                t.url.removePrefix("https://").removePrefix("http://").substringBefore('/')
            }.ifBlank { "Neuer Tab" }
            val chipColor by animateColorAsState(
                if (selected) Brand.Violet.copy(alpha = 0.18f) else Color.White.copy(alpha = 0.45f),
                animationSpec = tween(250), label = "tabColor"
            )
            val chipBorder by animateColorAsState(
                if (selected) Brand.Violet.copy(alpha = 0.6f) else Color.Transparent,
                animationSpec = tween(250), label = "tabBorder"
            )
            Surface(
                onClick = { onSelect(t.id) },
                shape = RoundedCornerShape(14.dp),
                color = chipColor,
                border = BorderStroke(1.dp, chipBorder),
                modifier = Modifier.height(30.dp).animateItem().tapFx(14.dp)
            ) {
                Row(Modifier.padding(start = 12.dp, end = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(label, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 130.dp))
                    IconButton(onClick = { onClose(t.id) }, modifier = Modifier.size(26.dp)) {
                        Icon(Icons.Filled.Close, contentDescription = "Tab schließen", modifier = Modifier.size(12.dp))
                    }
                }
            }
        }
        item {
            Surface(
                onClick = onNew,
                shape = RoundedCornerShape(14.dp),
                color = Color.White.copy(alpha = 0.45f),
                modifier = Modifier.height(30.dp).tapFx(14.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Neuer Tab", modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp))
            }
        }
    }
}

@Composable
private fun BottomNav(
    vpnOn: Boolean,
    onStart: () -> Unit,
    onBookmarks: () -> Unit,
    onHistory: () -> Unit,
    onVpn: () -> Unit,
    onJarvis: () -> Unit,
    onSettings: () -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(Brush.horizontalGradient(listOf(Color.Transparent, Brand.Violet.copy(alpha = 0.35f), Color.Transparent))))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            NavItem(Icons.Filled.Home, "Start", false, onStart, Modifier.weight(1f))
            NavItem(Icons.Filled.Star, "Lesezeichen", false, onBookmarks, Modifier.weight(1f))
            NavItem(Icons.Filled.History, "Verlauf", false, onHistory, Modifier.weight(1f))
            NavItem(Icons.Filled.Shield, "VPN", vpnOn, onVpn, Modifier.weight(1f))
            NavItem(Icons.Filled.AutoAwesome, "JARVIS", false, onJarvis, Modifier.weight(1f))
            NavItem(Icons.Filled.Settings, "Einstellungen", false, onSettings, Modifier.weight(1f))
        }
    }
}

/** Nur Symbol (Beschriftung bleibt als contentDescription für TalkBack), dafür deutlich flacher. */
@Composable
private fun NavItem(icon: ImageVector, label: String, active: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val scale by animateFloatAsState(if (active) 1.18f else 1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "navScale")
    val tint by animateColorAsState(
        if (active) Brand.VioletDeep else MaterialTheme.colorScheme.onSurfaceVariant,
        animationSpec = tween(250), label = "navTint"
    )
    Surface(onClick = onClick, color = Color.Transparent, modifier = modifier.tapFx(16.dp)) {
        Box(Modifier.fillMaxWidth().height(44.dp), contentAlignment = Alignment.Center) {
            Icon(
                icon, contentDescription = label, tint = tint,
                modifier = Modifier.size(22.dp).graphicsLayer { scaleX = scale; scaleY = scale }
            )
            if (active) {
                Box(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp)
                        .size(width = 14.dp, height = 3.dp).clip(CircleShape).background(Brand.accent)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsSheet(
    state: BrowserUiState,
    tab: TabUi,
    bookmarked: Boolean,
    onDismiss: () -> Unit,
    onThemeMode: (String) -> Unit,
    onReload: () -> Unit,
    onToggleBookmark: () -> Unit,
    onShare: () -> Unit,
    onSearchEngine: () -> Unit,
    onToggleMixed: () -> Unit,
    onClearHistory: () -> Unit,
    soundOn: Boolean,
    onSoundToggle: () -> Unit,
    glowOn: Boolean,
    onGlowToggle: () -> Unit,
    desktopOn: Boolean,
    onDesktopToggle: () -> Unit,
    jarvisEnabled: Boolean,
    onJarvisEnabledChange: (Boolean) -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 32.dp)) {
            Text("Einstellungen", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            Text("Darstellung", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("auto" to "Auto", "light" to "Hell", "dark" to "Dunkel").forEach { (id, label) ->
                    val sel = state.themeMode == id
                    Surface(
                        onClick = { onThemeMode(id) },
                        shape = RoundedCornerShape(28.dp),
                        color = if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.weight(1f).tapFx(28.dp)
                    ) {
                        Text(
                            label,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "Standard-Suchmaschine: ${state.searchEngine.name}. Verlauf und Lesezeichen bleiben nur in diesem Browser gespeichert.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Spacer(Modifier.height(8.dp))
            Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surfaceContainerLow) {
                Column(Modifier.fillMaxWidth()) {
                    if (tab.url.isNotBlank()) { SheetRow("Seite neu laden", onReload); HorizontalDivider() }
                    if (UrlTools.isWebUrl(tab.url)) {
                        SheetRow(if (bookmarked) "Lesezeichen entfernen" else "Lesezeichen hinzufügen", onToggleBookmark)
                        HorizontalDivider()
                        SheetRow("Link teilen", onShare)
                        HorizontalDivider()
                    }
                    SheetRow("Suchmaschine ändern", onSearchEngine)
                    HorizontalDivider()
                    SheetRow("Tropfen-Sound", onSoundToggle) {
                        Switch(checked = soundOn, onCheckedChange = null)
                    }
                    HorizontalDivider()
                    SheetRow("Violettes Leuchten mit Sternen", onGlowToggle) {
                        Switch(checked = glowOn, onCheckedChange = null)
                    }
                    HorizontalDivider()
                    SheetRow("Desktop-Modus", onDesktopToggle) {
                        Switch(checked = desktopOn, onCheckedChange = null)
                    }
                    HorizontalDivider()
                    SheetRow("Unsichere Inhalte auf HTTPS-Seiten erlauben", onToggleMixed) {
                        Switch(checked = state.allowMixedContent, onCheckedChange = null)
                    }
                    HorizontalDivider()
                    SheetRow("Verlauf löschen", onClearHistory)
                    HorizontalDivider()
                    SheetRow(
                        if (jarvisEnabled) "JARVIS ist aktiviert" else "JARVIS ist deaktiviert",
                        onClick = { onJarvisEnabledChange(!jarvisEnabled) }
                    ) {
                        Switch(
                            checked = jarvisEnabled,
                            onCheckedChange = onJarvisEnabledChange
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SheetRow(text: String, onClick: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Surface(onClick = onClick, color = Color.Transparent, modifier = Modifier.fillMaxWidth().tapFx(12.dp)) {
        Row(Modifier.padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(text, modifier = Modifier.weight(1f))
            trailing()
        }
    }
}

@Composable
private fun FullscreenOverlay(view: android.view.View, onExit: () -> Unit) {
    BackHandler(onBack = onExit)
    val activity = LocalActivity.current
    DisposableEffect(activity) {
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }
    AndroidView(
        modifier = Modifier.fillMaxSize().background(Color.Black),
        factory = { view.also { (it.parent as? ViewGroup)?.removeView(it) } }
    )
}

private fun shareLink(context: android.content.Context, url: String) {
    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, url)
    context.startActivity(Intent.createChooser(send, context.getString(R.string.share_chooser)))
}
