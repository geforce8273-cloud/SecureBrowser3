package de.deinname.securebrowse.ui

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import de.deinname.securebrowse.browser.BrowserViewModel
import de.deinname.securebrowse.browser.WebViewRegistry
import de.deinname.securebrowse.vpn.EncryptedVpnProfileStore
import de.deinname.securebrowse.vpn.OpenVpnController
import de.deinname.securebrowse.vpn.WireGuardController

object Routes {
    const val BROWSER = "browser"
    const val TABS = "tabs"
    const val BOOKMARKS = "bookmarks"
    const val HISTORY = "history"
    const val VPN = "vpn"
    const val JARVIS = "jarvis"
}

@Composable
fun AppNavigation(
    viewModel: BrowserViewModel,
    registry: WebViewRegistry,
    wireGuardController: WireGuardController,
    openVpnController: OpenVpnController,
    vpnProfileStore: EncryptedVpnProfileStore,
    jarvisController: de.deinname.securebrowse.jarvis.JarvisController
) {
    val nav = rememberNavController()

    fun openUrlInCurrentTab(url: String) {
        val tab = viewModel.state.value.selectedTab ?: return
        registry.load(tab.id, url)
        nav.popBackStack(Routes.BROWSER, inclusive = false)
    }

    Box(Modifier.fillMaxSize()) {
    AuroraBackground(Modifier.fillMaxSize())
    NavHost(
        navController = nav,
        startDestination = Routes.BROWSER,
        enterTransition = { slideInHorizontally(animationSpec = tween(340), initialOffsetX = { it / 6 }) + fadeIn(tween(340)) },
        exitTransition = { scaleOut(animationSpec = tween(260), targetScale = 0.95f) + fadeOut(tween(220)) },
        popEnterTransition = { scaleIn(animationSpec = tween(300), initialScale = 0.95f) + fadeIn(tween(300)) },
        popExitTransition = { slideOutHorizontally(animationSpec = tween(300), targetOffsetX = { it / 6 }) + fadeOut(tween(240)) }
    ) {
        composable(Routes.BROWSER) {
            BrowserScreen(
                viewModel = viewModel,
                registry = registry,
                onOpenTabs = { nav.navigate(Routes.TABS) },
                onOpenBookmarks = { nav.navigate(Routes.BOOKMARKS) },
                onOpenHistory = { nav.navigate(Routes.HISTORY) },
                onOpenVpn = { nav.navigate(Routes.VPN) },
                onOpenJarvis = { nav.navigate(Routes.JARVIS) },
                jarvisController = jarvisController,
                vpnConnected = { wireGuardController.isConnected() || openVpnController.isConnected() }
            )
        }
        composable(Routes.TABS) {
            TabsScreen(viewModel, registry, onBack = { nav.popBackStack() })
        }
        composable(Routes.BOOKMARKS) {
            BookmarksScreen(viewModel, onBack = { nav.popBackStack() }, onOpen = ::openUrlInCurrentTab)
        }
        composable(Routes.HISTORY) {
            HistoryScreen(viewModel, onBack = { nav.popBackStack() }, onOpen = ::openUrlInCurrentTab)
        }
        composable(Routes.JARVIS) { JarvisScreen(jarvisController, jarvisController.modelManager, onBack = { nav.popBackStack() }) }
        composable(Routes.VPN) {
            VpnScreen(
                wireGuard = wireGuardController,
                openVpn = openVpnController,
                store = vpnProfileStore,
                onBack = { nav.popBackStack() }
            )
        }
    }
    }
}
