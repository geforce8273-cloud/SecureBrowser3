package de.deinname.securebrowse.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

private val Context.browserDataStore: DataStore<Preferences> by preferencesDataStore(name = "browser")

/**
 * Persists bookmarks, history, tabs and the search engine in Jetpack DataStore (Preferences).
 * Values are stored as small JSON documents (org.json is part of the Android platform, no extra dependency).
 * Note: this data is NOT encrypted. Only VPN profiles (phase 2) get Keystore encryption.
 */
class BrowserStore(context: Context) {
    private val dataStore: DataStore<Preferences> = context.applicationContext.browserDataStore

    private val prefs: Flow<Preferences> = dataStore.data.catch { e ->
        if (e is IOException) emit(emptyPreferences()) else throw e
    }

    val bookmarks: Flow<List<Bookmark>> =
        prefs.map { decodeBookmarks(it[KEY_BOOKMARKS]) }.distinctUntilChanged()

    val history: Flow<List<HistoryEntry>> =
        prefs.map { decodeHistory(it[KEY_HISTORY]) }.distinctUntilChanged()

    val searchEngineId: Flow<String> =
        prefs.map { it[KEY_SEARCH_ENGINE] ?: SearchEngines.DuckDuckGo.id }.distinctUntilChanged()

    /** "auto" | "light" | "dark" */
    val themeMode: Flow<String> =
        prefs.map { it[KEY_THEME_MODE] ?: "auto" }.distinctUntilChanged()

    suspend fun setThemeMode(mode: String) {
        dataStore.edit { it[KEY_THEME_MODE] = mode }
    }

    val allowMixedContent: Flow<Boolean> =
        prefs.map { it[KEY_ALLOW_MIXED] ?: false }.distinctUntilChanged()

    suspend fun setAllowMixedContent(allowed: Boolean) {
        dataStore.edit { it[KEY_ALLOW_MIXED] = allowed }
    }

    suspend fun setSearchEngine(id: String) {
        dataStore.edit { it[KEY_SEARCH_ENGINE] = id }
    }

    /** Adds the bookmark if absent, removes it if present. Returns true when it was added. */
    suspend fun toggleBookmark(url: String, title: String): Boolean {
        var added = false
        dataStore.edit { p ->
            val list = decodeBookmarks(p[KEY_BOOKMARKS]).toMutableList()
            val index = list.indexOfFirst { it.url == url }
            if (index >= 0) {
                list.removeAt(index)
            } else {
                list.add(0, Bookmark(url, title, System.currentTimeMillis()))
                added = true
            }
            p[KEY_BOOKMARKS] = encodeBookmarks(list)
        }
        return added
    }

    suspend fun deleteBookmark(url: String) {
        dataStore.edit { p ->
            p[KEY_BOOKMARKS] = encodeBookmarks(decodeBookmarks(p[KEY_BOOKMARKS]).filterNot { it.url == url })
        }
    }

    suspend fun addHistory(url: String, title: String) {
        dataStore.edit { p ->
            val list = decodeHistory(p[KEY_HISTORY]).toMutableList()
            if (list.firstOrNull()?.url == url) list.removeAt(0) // collapse consecutive duplicates
            list.add(0, HistoryEntry(url, title, System.currentTimeMillis()))
            p[KEY_HISTORY] = encodeHistory(list.take(HISTORY_LIMIT))
        }
    }

    suspend fun clearHistory() {
        dataStore.edit { it.remove(KEY_HISTORY) }
    }

    suspend fun saveTabs(tabs: SavedTabs) {
        dataStore.edit { it[KEY_TABS] = encodeTabs(tabs) }
    }

    suspend fun loadTabs(): SavedTabs? = decodeTabs(prefs.first()[KEY_TABS])

    // ---- JSON helpers: corrupt data never crashes the app, it just yields an empty result ----

    private fun encodeBookmarks(list: List<Bookmark>): String = JSONArray().also { arr ->
        list.forEach {
            arr.put(JSONObject().put("u", it.url).put("t", it.title).put("c", it.createdAt))
        }
    }.toString()

    private fun decodeBookmarks(raw: String?): List<Bookmark> = parseArray(raw) { o ->
        Bookmark(o.getString("u"), o.optString("t"), o.optLong("c"))
    }

    private fun encodeHistory(list: List<HistoryEntry>): String = JSONArray().also { arr ->
        list.forEach {
            arr.put(JSONObject().put("u", it.url).put("t", it.title).put("v", it.visitedAt))
        }
    }

    private fun decodeHistory(raw: String?): List<HistoryEntry> = parseArray(raw) { o ->
        HistoryEntry(o.getString("u"), o.optString("t"), o.optLong("v"))
    }

    private fun encodeTabs(tabs: SavedTabs): String {
        val arr = JSONArray()
        tabs.tabs.forEach { arr.put(JSONObject().put("i", it.id).put("u", it.url).put("t", it.title)) }
        val root = JSONObject().put("tabs", arr)
        tabs.selectedId?.let { root.put("s", it) }
        return root.toString()
    }

    private fun decodeTabs(raw: String?): SavedTabs? {
        if (raw.isNullOrBlank()) return null
        return try {
            val root = JSONObject(raw)
            val arr = root.getJSONArray("tabs")
            val tabs = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                SavedTab(o.getLong("i"), o.getString("u"), o.optString("t"))
            }
            SavedTabs(tabs, if (root.has("s")) root.getLong("s") else null)
        } catch (_: Exception) {
            null
        }
    }

    private fun <T> parseArray(raw: String?, mapper: (JSONObject) -> T): List<T> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                try { mapper(arr.getJSONObject(i)) } catch (_: Exception) { null }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private companion object {
        const val HISTORY_LIMIT = 500
        val KEY_BOOKMARKS = stringPreferencesKey("bookmarks")
        val KEY_HISTORY = stringPreferencesKey("history")
        val KEY_TABS = stringPreferencesKey("tabs")
        val KEY_SEARCH_ENGINE = stringPreferencesKey("search_engine")
        val KEY_THEME_MODE = stringPreferencesKey("theme_mode")
        val KEY_ALLOW_MIXED = booleanPreferencesKey("allow_mixed_content")
    }
}
