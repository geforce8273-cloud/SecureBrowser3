package de.deinname.securebrowse.jarvis

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Phase 1 foundation. No model is claimed to be loaded until a real runtime is connected. */
data class JarvisCapabilities(
    val inferenceAvailable: Boolean = false,
    val voiceInputAvailable: Boolean = false,
    val speechOutputAvailable: Boolean = false,
    val visionAvailable: Boolean = false,
    val webResearchAvailable: Boolean = false
)

interface JarvisInferenceEngine {
    val modelName: String?
    suspend fun generate(prompt: String, conversation: List<JarvisMessage> = emptyList()): String
    suspend fun isReady(): Boolean

    /** Stops a running generation as fast as possible. Must be safe to call from any thread at any time. */
    fun cancel()
}

data class JarvisMessage(val role: String, val content: String, val createdAt: Long = System.currentTimeMillis())

/** Explicit unavailable engine prevents accidental fake/demo answers. */
class UnconfiguredInferenceEngine : JarvisInferenceEngine {
    override val modelName: String? = null
    override suspend fun generate(prompt: String, conversation: List<JarvisMessage>): String =
        error("Kein KI-Modell installiert. Die Inferenz ist noch nicht eingerichtet.")
    override suspend fun isReady(): Boolean = false
    override fun cancel() = Unit
}

class JarvisMemory(context: Context) : SQLiteOpenHelper(context, "jarvis_memory.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE memories (id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL, content TEXT NOT NULL, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE conversations (id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, content TEXT NOT NULL, created_at INTEGER NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { }

    suspend fun saveMemory(category: String, content: String) = withContext(Dispatchers.IO) {
        writableDatabase.execSQL("INSERT INTO memories(category, content, created_at) VALUES(?,?,?)", arrayOf<Any?>(category, content, System.currentTimeMillis()))
    }
    suspend fun recentMemories(limit: Int = 50): List<Pair<String, String>> = withContext(Dispatchers.IO) {
        val result = mutableListOf<Pair<String, String>>()
        readableDatabase.rawQuery("SELECT category, content FROM memories ORDER BY created_at DESC LIMIT ?", arrayOf(limit.coerceIn(1, 200).toString())).use { c ->
            while (c.moveToNext()) result += c.getString(0) to c.getString(1)
        }
        result
    }
}

class JarvisController(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)
    val memory = JarvisMemory(context.applicationContext)
    val modelManager = JarvisModelManager(context.applicationContext)
    /** Real llama.cpp engine. Reports "not ready" until a model was loaded; never produces fake answers. */
    val engine = LlamaInferenceEngine(context.applicationContext, modelManager)
    val inference: JarvisInferenceEngine get() = engine
    fun isEnabled(): Boolean = prefs.getBoolean("enabled", false)
    fun setEnabled(enabled: Boolean) { prefs.edit().putBoolean("enabled", enabled).apply() }
}
