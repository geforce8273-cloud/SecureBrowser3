package de.deinname.securebrowse.browser

import java.net.URLEncoder
import java.net.URI

/** Pure Kotlin so it can be unit-tested on the JVM. Never throws. */
object UrlTools {

    enum class SchemeAction { LOAD, EXTERNAL, BLOCK }

    private val webPrefix = Regex("^https?://", RegexOption.IGNORE_CASE)

    /** Server name with an explicit port and no dot, e.g. "nas:8080" or "myserver:3000" (2-5 digit port). */
    private val hostWithPort = Regex("^[A-Za-z0-9][A-Za-z0-9_-]*:\\d{2,5}$")

    /** Anything starting with these is never searched for and never loaded from the address bar. */
    private val rejectedPrefixes = listOf(
        "javascript:", "vbscript:", "file:", "content:", "data:", "blob:", "about:",
        "view-source:", "intent:", "mailto:", "tel:", "sms:", "ftp:", "market:"
    )

    /**
     * Turns address-bar input into a URL to load.
     * - http(s) URLs with a host are returned unchanged
     * - dangerous / unsupported schemes return null
     * - bare hosts get https://; there is deliberately no automatic HTTP downgrade
     * - everything else becomes a search URL
     */
    fun resolve(input: String, searchTemplate: String): String? = resolveNavigation(input, searchTemplate)?.url

    /** Resolved navigation target. Bare hosts are HTTPS-only; HTTP is accepted only when explicitly typed. */
    data class Resolved(val url: String)

    fun resolveNavigation(input: String, searchTemplate: String): Resolved? {
        // Reject invisible direction/format controls instead of silently carrying them into
        // an address. They can make a displayed hostname differ from its actual destination.
        if (input.any(::isUnsafeFormatCharacter)) return null
        val value = input.filterNot { it.isISOControl() }.trim()
        if (value.isEmpty()) return null
        if (webPrefix.containsMatchIn(value)) return value.takeIf { hasHost(it) }?.let { Resolved(LinkTools.stripTrackingParameters(it)) }
        val lower = value.lowercase()
        if (rejectedPrefixes.any { lower.startsWith(it) }) return null
        if (looksLikeHost(value)) {
            val https = "https://$value"
            return if (hasHost(https)) Resolved(https) else null
        }
        return Resolved(searchUrl(value, searchTemplate))
    }

    fun searchUrl(query: String, template: String): String =
        template.replace("%s", URLEncoder.encode(query, "UTF-8"))

    fun schemeAction(scheme: String?): SchemeAction = when (scheme?.lowercase()) {
        "http", "https" -> SchemeAction.LOAD
        "mailto", "tel", "sms", "intent" -> SchemeAction.EXTERNAL
        else -> SchemeAction.BLOCK // javascript, file, content, data, blob, unknown custom schemes
    }

    fun isHttps(url: String): Boolean = url.startsWith("https://", ignoreCase = true)

    fun isHttp(url: String): Boolean = url.startsWith("http://", ignoreCase = true)

    fun isWebUrl(url: String): Boolean = isHttps(url) || isHttp(url)

    private fun looksLikeHost(value: String): Boolean {
        if (value.any { it.isWhitespace() }) return false
        if (value.startsWith(".") || value.startsWith("?") || value.startsWith("/")) return false
        val hostPart = value.substringBefore('/').substringBefore('?').substringBefore('#')
        if (hostPart.contains('.') || hostPart.startsWith("localhost", ignoreCase = true) || hostPart.startsWith("[")) {
            return true
        }
        val port = hostPart.substringAfter(':', "").toIntOrNull()
        return hostWithPort.matches(hostPart) && port != null && port in 1..65535
    }

    /** host[:port] made of Unicode letters/digits, '-', '_' and '.', nothing else (no user info, brackets or escapes). */
    private val relaxedAuthority = Regex("^([\\p{L}\\p{N}_.-]+)(?::(\\d{1,5}))?$")

    private fun isUnsafeFormatCharacter(ch: Char): Boolean =
        ch in '\u200B'..'\u200F' || ch in '\u202A'..'\u202E' ||
            ch in '\u2060'..'\u206F' || ch == '\uFEFF' || ch == '\u061C'

    private fun hasHost(url: String): Boolean {
        // Parse instead of manually splitting the authority: malformed ports, spaces,
        // and bracketed IPv6 edge cases must not be accepted as navigable URLs.
        return try {
            val parsed = URI(url)
            val scheme = parsed.scheme?.lowercase()
            val authority = parsed.rawAuthority
            if ((scheme != "http" && scheme != "https") || authority.isNullOrBlank() || parsed.rawUserInfo != null) {
                false
            } else {
                val host = parsed.host
                if (host != null) {
                    host.isNotBlank() && host.none { it.isWhitespace() } &&
                        (parsed.port == -1 || parsed.port in 1..65535)
                } else {
                    isRelaxedAuthority(authority)
                }
            }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * java.net.URI returns no host for internationalized names (bücher.de) and for names with
     * underscores (my_server), although browsers load both. Such names are accepted only in the plain
     * "host[:port]" shape; user info, brackets, percent escapes and empty labels stay rejected.
     */
    private fun isRelaxedAuthority(authority: String): Boolean {
        val match = relaxedAuthority.matchEntire(authority) ?: return false
        val host = match.groupValues[1]
        val port = match.groupValues[2]
        return host.trimEnd('.').split('.').none { it.isEmpty() } &&
            (port.isEmpty() || port.toInt() in 1..65535)
    }
}
