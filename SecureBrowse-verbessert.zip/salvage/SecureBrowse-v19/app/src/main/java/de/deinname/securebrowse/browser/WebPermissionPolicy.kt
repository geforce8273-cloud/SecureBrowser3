package de.deinname.securebrowse.browser

import android.webkit.PermissionRequest
import java.net.URI

/** Restricts website capture permissions to secure HTTPS origins and known WebView resources. */
internal object WebPermissionPolicy {
    fun allowedResources(origin: String, resources: List<String>): List<String> {
        val secureOrigin = runCatching {
            val uri = URI(origin)
            uri.scheme.equals("https", ignoreCase = true) &&
                !uri.host.isNullOrBlank() && uri.rawUserInfo == null &&
                (uri.port == -1 || uri.port in 1..65535)
        }.getOrDefault(false)
        if (!secureOrigin) return emptyList()

        return resources.filter {
            it == PermissionRequest.RESOURCE_VIDEO_CAPTURE ||
                it == PermissionRequest.RESOURCE_AUDIO_CAPTURE
        }.distinct()
    }
}
