package de.deinname.securebrowse.browser

import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.util.Locale

/**
 * Lightweight built-in ad/tracker filter for WebView requests.
 * This is intentionally separate from Safe Browsing and from any user-managed site blocklist.
 * The domain set is a conservative starter list; it is not a replacement for full EasyList rules.
 */
internal object AdBlocker {
    private val blockedHosts = setOf(
        // Advertising networks
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "pagead2.googlesyndication.com", "adnxs.com",
        "adsrvr.org", "advertising.com", "adform.net", "adform.com",
        "adcolony.com", "adroll.com", "adsafeprotected.com", "adsterra.com",
        "adthrive.com", "bidswitch.net", "bluekai.com", "casalemedia.com",
        "contextweb.com", "criteo.com", "criteo.net", "media.net",
        "outbrain.com", "popads.net", "pubmatic.com", "serving-sys.com",
        "sharethrough.com", "teads.tv", "thetradedesk.com",
        "zedo.com", "smartadserver.com", "rubiconproject.com",
        "33across.com", "lijit.com", "openx.net", "openx.com",
        "yieldmo.com", "gumgum.com", "undertone.com", "triplelift.com",
        "appnexus.com", "bidswitch.net", "exelator.com", "eyeota.net",
        // Analytics and tracking
        "google-analytics.com", "analytics.google.com", "googletagmanager.com",
        "connect.facebook.net", "pixel.facebook.com",
        "static.hotjar.com", "mixpanel.com", "segment.io",
        "api.segment.io", "amplitude.com", "clarity.ms",
        "bat.bing.com", "ads.linkedin.com", "snap.licdn.com", "t.co",
        "app-measurement.com", "scorecardresearch.com",
        "quantserve.com", "quantcount.com", "newrelic.com", "nr-data.net",
        "crazyegg.com", "luckyorange.com", "heap.io",
        "heapanalytics.com", "optimizely.com", "outbrain.com",
        "segment.com", "segment.io", "fullstory.com", "mouseflow.com",
        "hotjar.com", "contentsquare.net", "contentsquare.com",
        "statsig.com", "posthog.com", "plausible.io", "matomo.cloud",
        "adjust.com", "appsflyer.com", "branch.io", "kochava.com"
    ).map { it.trim().lowercase(Locale.ROOT) }.filter { it.isNotEmpty() }.toSet()

    fun shouldBlock(uri: Uri): Boolean {
        if (uri.scheme != "http" && uri.scheme != "https") return false
        val host = uri.host?.trimEnd('.')?.lowercase(Locale.ROOT) ?: return false
        return blockedHosts.any { blocked -> host == blocked || host.endsWith(".$blocked") }
    }

    fun blockedResponse(): WebResourceResponse = WebResourceResponse(
        "text/plain",
        "utf-8",
        204,
        "No Content",
        emptyMap(),
        ByteArrayInputStream(ByteArray(0))
    )
}
