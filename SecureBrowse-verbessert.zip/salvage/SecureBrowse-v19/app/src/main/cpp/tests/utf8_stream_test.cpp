// Host test (no Android needed):  g++ -std=c++17 -Wall -Wextra -I.. utf8_stream_test.cpp -o /tmp/utf8_test && /tmp/utf8_test
#include <algorithm>
#include <cstdio>
#include <string>
#include <vector>
#include "utf8_stream.h"

static bool valid_utf8(const std::string& s) {
    size_t i = 0;
    while (i < s.size()) {
        unsigned char c = s[i];
        size_t len = c < 0x80 ? 1 : (c >= 0xC2 && c < 0xE0) ? 2 : (c >= 0xE0 && c < 0xF0) ? 3 : (c >= 0xF0 && c <= 0xF4) ? 4 : 0;
        if (len == 0 || i + len > s.size()) return false;
        for (size_t k = 1; k < len; ++k) if ((static_cast<unsigned char>(s[i + k]) & 0xC0) != 0x80) return false;
        i += len;
    }
    return true;
}

static int failures = 0;
#define CHECK(cond) do { if (!(cond)) { std::printf("FAIL line %d: %s\n", __LINE__, #cond); ++failures; } } while (0)

static void run_split(const std::string& text, size_t chunk) {
    jarvis::Utf8Stream stream;
    std::string joined;
    for (size_t i = 0; i < text.size(); i += chunk) {
        std::string out = stream.push(text.data() + i, std::min(chunk, text.size() - i));
        CHECK(valid_utf8(out));      // every emitted piece is valid on its own
        joined += out;
    }
    joined += stream.flush();
    CHECK(joined == text);           // nothing lost, nothing duplicated
}

int main() {
    const std::string text = u8"Hallo Welt! Größe: 5 € – 😀 Ende ü";
    for (size_t chunk = 1; chunk <= 7; ++chunk) run_split(text, chunk);

    jarvis::Utf8Stream s;
    CHECK(s.push("\xF0\x9F", 2).empty());                 // incomplete emoji is held back
    CHECK(s.push("\x98", 1).empty());
    CHECK(s.push("\x80", 1) == "\xF0\x9F\x98\x80");       // completed on the last byte
    CHECK(s.push("a", 1) == "a");
    CHECK(s.push("\xE2\x82", 2).empty());
    CHECK(s.flush() == "\xE2\x82");                       // flush returns the unfinished tail

    if (failures == 0) std::printf("OK: all utf8_stream tests passed\n");
    return failures == 0 ? 0 : 1;
}
