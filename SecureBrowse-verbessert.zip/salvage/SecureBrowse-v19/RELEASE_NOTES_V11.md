# SecureBrowse v11 – Sicherheits- und Produkt-Ausbau

Stand: 22.11.2026

## In dieser Quellcode-Version tatsächlich geändert

- Android WebView Safe Browsing ist wieder aktiviert. Die vorherige Version hatte es global im Manifest und zusätzlich pro WebView deaktiviert. Android empfiehlt, Safe Browsing eingeschaltet zu lassen. Je nach Android System-WebView und Gerät kann die Verfügbarkeit variieren.
- WebView-Metrik-Opt-out bleibt aktiv.
- Der lokale Ad-/Tracker-Hostfilter wurde um weitere bekannte Werbe-, Analyse- und Session-Replay-Domains ergänzt.
- Versionsnummer auf 0.2.0 / versionCode 2 angehoben.
- Das bestehende UI-/Theme-/Layout-Verzeichnis wurde nicht geändert.

## Was diese Änderungen NICHT bedeuten

- Der Filter ist weiterhin eine Domain-Blockliste und keine vollständige EasyList-/uBlock-Origin-Engine. `shouldInterceptRequest` sieht nicht jede Art von WebView-Ressource und bei Redirects nur die ursprüngliche URL. Ein VPN-weites DNS-/App-weites Blockieren ist damit nicht gegeben.
- Safe Browsing ist ein zusätzlicher Schutz vor bekannten gefährlichen Seiten, keine Garantie gegen Phishing oder Malware. Die WebView-/Android-Komponente entscheidet über Verfügbarkeit und Aktualität.
- Tor bleibt nicht implementiert: `NoTorBackend` liefert absichtlich einen Fehler. Die Tor-Oberfläche darf nicht als aktive Anonymisierung verstanden werden.
- WireGuard kann nur mit einem gültigen Profil und erreichbarem Server verbinden. Die App stellt selbst keine VPN-Server bereit.
- JARVIS bleibt von einem korrekt eingebundenen nativen llama.cpp-Build und einem kompatiblen lokal importierten GGUF-Modell abhängig.

## Noch zwingend vor einer Veröffentlichung

1. Echten Gradle-Wrapper erzeugen und Build mit installierter SDK/NDK-Toolchain ausführen.
2. Unit-Tests und Dependency-Guard ausführen.
3. Merge-Manifest, Exported Components, Netzwerkverkehr und APK-Abhängigkeiten prüfen.
4. Physische Gerätetests: WebView Safe Browsing, Redirects, Downloads, Berechtigungen, Renderer-Crash, VPN DNS/IPv4/IPv6/Leak-Schutz, WLAN/Mobilfunk-Wechsel und Akkuverbrauch.
5. Tor-Integration nur über eine gepflegte, nachvollziehbare Tor-Implementierung und mit vollständigen DNS-/IPv6-/UDP-/WebRTC-Leaktests ergänzen. Bis dahin Tor-Schaltfläche als nicht verfügbar kennzeichnen.
6. JARVIS-Modell-Lizenzen, Modell-Import, RAM-/Temperaturgrenzen, Prompt-Injection-Grenzen und Offline-Verhalten prüfen.

## Nächste sinnvolle Produktphasen

- Browser: Find-in-page, Download-Manager, QR-URL-Scanner, Lesemodus, Reader-/Textzoom, Website-Daten pro Domain löschen, Cookie-/Cache-Kontrolle, Import/Export von Lesezeichen.
- Privatsphäre: echte Filterlisten mit signierten/versionsgebundenen Updates, Allowlist, pro-Seite Blockstatistik, HTTPS-only-Modus mit expliziter HTTP-Ausnahme, sichere private Tabs.
- Netzwerk: WireGuard-Statusdiagnose und Leak-Tests; Tor erst nach sauberer Engine-Integration.
- JARVIS: lokale Modellverwaltung, explizite Berechtigungen, getrennte Browser-Recherche mit Quellen, kein automatisches Ausführen von Webseiten-Anweisungen, sichtbare Datenfreigabe.
- Qualität: CI-Build, UI-Tests, Baseline-/Macrobenchmark, Crash- und Speicherprüfungen ohne Drittanbieter-Tracking.
