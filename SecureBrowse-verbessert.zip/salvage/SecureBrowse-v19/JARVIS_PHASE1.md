# JARVIS – Phase 1: Grundarchitektur

## Implementiert
- Eigenständiges Paket `de.deinname.securebrowse.jarvis`.
- `JarvisController` als zentraler Einstiegspunkt.
- Dauerhafte Ein-/Aus-Einstellung über Android SharedPreferences.
- Lokale SQLite-Datenbank `jarvis_memory.db` mit Tabellen für Erinnerungen und Konversationsnachrichten.
- `JarvisInferenceEngine` als Vertrag für eine spätere echte Modell-Laufzeit.
- `UnconfiguredInferenceEngine` liefert ausdrücklich keine Demo-Antworten, sondern meldet fehlende Modellinstallation.
- JARVIS-Menüpunkt in der Browser-Navigation und eigene Statusoberfläche.

## Noch nicht implementiert
- Echtes lokales Sprachmodell und Inferenz.
- Modell-Download/-Manager und Hardwareprüfung.
- Online-KI-Anbindung.
- Mikrofon, Spracherkennung und Sprachausgabe.
- Vision-/Videoanalyse und Browser-Webschutz.

## Tests / Grenzen
Die Quellstruktur und Verknüpfungen wurden geprüft. Ein Android-Build konnte in dieser Umgebung nicht ausgeführt werden: Im gelieferten ZIP fehlt `gradle-wrapper.jar` und es ist kein ausführbarer Gradle-Wrapper enthalten. Daher wird kein erfolgreicher Build oder Gerätetest behauptet. Vor Phase 2 muss ein vollständiger Gradle-Wrapper ergänzt und ein Android-Build ausgeführt werden.
