# Verbesserungen 22.11.2026 – weiterer Durchgang

## OpenVPN-Validator
- Inline-Blöcke werden nicht mehr still über verschachtelte oder falsche Block-Ende-Markierungen hinweg ignoriert.
- Ungültige Blockmarkierungen innerhalb eines erlaubten Inline-Blocks führen zum fail-closed Abbruch.
- Unit-Tests für verschachtelte und falsch geschlossene Markierungen ergänzt.

## Überprüfungen in dieser Umgebung
- Bash-Syntax der drei Tools-Skripte: erfolgreich (`bash -n`).
- Gradle/Android-Build und Tests nicht ausgeführt: Gradle-Executable/Wrapper-JAR sowie Android SDK nicht in dieser Umgebung verfügbar.
- Diese Änderung ist eine Quellcode-Härtung, kein bestätigter APK-Build.
