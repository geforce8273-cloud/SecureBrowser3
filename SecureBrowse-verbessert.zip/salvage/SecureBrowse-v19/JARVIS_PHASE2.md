# JARVIS – Phase 2 (Teil A): GGUF-Modellverwaltung und Geräteprofil

## In diesem Stand umgesetzt
- GGUF-Datei über Android-Dateiauswahl importieren.
- Datei wird in den privaten App-Speicher `files/jarvis/models` kopiert.
- Prüfung von GGUF-Magic, Formatversion, Tensoranzahl und Metadatenanzahl.
- Modellpfad und Auswahl werden lokal gespeichert.
- Modell kann gewechselt oder aus dem App-Speicher entfernt werden.
- Geräteprofil zeigt erkannten Gesamtspeicher, verfügbaren RAM, Android-App-Speicherklasse und freien internen Speicher.
- UI kennzeichnet ausdrücklich, dass ein importiertes Modell noch nicht ausgeführt wird.

## Noch offen – Phase 2, Teil B
Die native llama.cpp-Laufzeit ist noch nicht eingebunden. Deshalb kann JARVIS in diesem Stand noch keine lokalen KI-Antworten generieren. Ein GGUF-Import ist keine Inferenz. Es fehlen insbesondere:
- Android-NDK/CMake-Build der llama.cpp-Bibliotheken für `arm64-v8a`.
- JNI/Kotlin-Anbindung zum Laden und Ausführen eines Modells.
- Abbruch, Speichergrenzen, Token-Streaming und Lifecycle-Tests auf dem Galaxy A53.
- Ein echtes, passend quantisiertes GGUF-Modell; es wird nicht ungefragt mit der App gebündelt.

## Technische Grundlage
Die Umsetzung folgt dem offiziellen llama.cpp Android-Leitfaden: https://github.com/ggml-org/llama.cpp/blob/master/docs/android.md
Dort wird die Android-Bindung über GGUF-Metadaten, eine InferenceEngine und Token-Streaming beschrieben. Die Android-NDK-Kompilierung muss für die Ziel-ABI gebaut werden. Für dieses Projekt wird `arm64-v8a` als Ziel vorgesehen; die konkrete RAM-Eignung wird auf dem Gerät ermittelt.

## Build-/Teststatus
- Quellcode und Navigation wurden angepasst.
- Ein Build konnte hier nicht ausgeführt werden: Im ZIP fehlt `gradle-wrapper.jar`, und auf der Ausführungsumgebung ist kein systemweites Gradle installiert.
- Es wird daher weder ein erfolgreicher APK-Build noch ein Gerätetest behauptet.

## Zusätzliche Verbesserungen am Modellimport
- Vor dem Import wird der verfügbare Speicher geprüft; nach dem Import sollen mindestens 200 MB frei bleiben.
- Auch bei Dateianbietern ohne bekannte Dateigröße wird der freie Speicher während des Kopierens überwacht.
- Der Import meldet den Kopierfortschritt in der JARVIS-Oberfläche.
- Die Geräteprüfung zeigt eine vorsichtige RAM-Warnung, wenn die GGUF-Datei im Verhältnis zum erkannten Arbeitsspeicher groß ist. Das ist nur eine Näherung und keine Garantie für die Laufzeitfähigkeit.
