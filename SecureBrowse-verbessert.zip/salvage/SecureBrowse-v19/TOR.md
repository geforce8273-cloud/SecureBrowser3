# Tor-Modus für SecureBrowse – ehrlicher Stand
Stand: 2026-11-22 · Verifikationsstatus: nur Gerüst, nicht verifiziert

## Was der Tor Browser macht (kurz)
1. Leitet allen Verkehr über das Tor-Netz (3 Relais, mehrschichtig verschlüsselt).
2. Isoliert Cookies pro Website, speichert nichts dauerhaft.
3. Vereinheitlicht Browser-Merkmale (Fingerprinting-Schutz) – das ist ein angepasster Firefox, nicht ein WebView.

## Was SecureBrowse kann und nicht kann
- Kann (vorbereitet): Tor-Modus mit strenger Policy (`tor/TorMode.kt`): kein Verlauf, keine Tab-Speicherung, keine dauerhaften Cookies, nur HTTPS, FLAG_SECURE, Kamera/Mikro/Standort aus, **Fail-closed** (ohne verbundenen Proxy lädt keine Seite), Proxy nur auf Loopback.
- Kann NICHT: den Fingerprinting-Schutz des Tor Browsers erreichen. Android-WebView ist Chromium und lässt sich nicht so angleichen. Deshalb darf die App nie "anonym" versprechen (A2.11). Für starken Schutz bleibt der echte Tor Browser für Android die bessere Wahl.

## Noch offen (Entscheidung nötig, nicht erfunden)
- Engine: (a) Orbot als getrennte App nutzen (SOCKS auf 127.0.0.1, keine neue Bibliothek in SBS), oder (b) tor-android von Guardian Project einbinden (github.com/guardianproject/tor-android; Version PRUEFEN, Lizenz und APK-Größe bewerten), oder (c) Arti (PRUEFEN: Android-Stand).
- WebView-Proxy: braucht `androidx.webkit` (`ProxyController`, developer.android.com/reference/androidx/webkit/ProxyController). Version PRUEFEN; bisher bewusst nicht eingebunden.
- PRUEFEN: ob DNS bei `socks5://` im WebView wirklich über den Proxy aufgelöst wird (DNS-Leak-Test auf dem Gerät).
- Zusammenspiel mit dem eigenen VPN (Tor über VPN oder umgekehrt) klären.

## Tor-Schalter in der App (v5)
- Schalter "Tor-Modus" über der unteren Leiste im Browser (`ui/TorUi.kt`). Aktiv: lila, langsam animierter Hintergrund (bei Android "Animationen entfernen" statisch).
- Weil noch keine Tor-Engine eingebaut ist, bleibt der Modus **fail-closed**: Er zeigt einen Hinweis, die Adressleiste lädt nichts. Normales Surfen: Schalter aus.
- Der Modus wird nicht gespeichert; nach einem App-Neustart ist er immer aus.
- Nicht verifiziert: Im Tor-Modus offene Seiten im Hintergrund werden nicht aktiv angehalten (Prüfpunkt für M2).
- Verbindung zu Orbot/tor-android folgt nach deiner Entscheidung (Engine) und einem grünen Build.
