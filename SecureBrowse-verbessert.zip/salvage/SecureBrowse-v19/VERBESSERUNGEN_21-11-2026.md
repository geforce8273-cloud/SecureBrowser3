# Verbesserungen an SecureBrowse (21.11.2026)

## Eingearbeitet
- URL-Validierung: explizite HTTP(S)-Adressen werden jetzt mit `java.net.URI` geprüft statt nur die Authority manuell zu zerlegen. Ungültige Hosts, fehlerhafte URLs und Ports außerhalb 1..65535 werden abgewiesen.
- Tests ergänzt: fehlerhafte HTTP(S)-URLs und gültige IPv6-Adresse mit Port.

## Noch nicht verifiziert
- Android/Gradle-Build, Unit-Tests und APK-Erzeugung konnten in dieser Arbeitsumgebung nicht ausgeführt werden (kein Wrapper-JAR/Gradle-Projektlauf nachgewiesen).
- Die separat hochgeladenen DEX-Dateien sind Dalvik-Binärdateien. Ohne zugehörige APK/Manifest, verlässliche Herkunft und passende Dekompilierungs-/Build-Werkzeuge wurden sie nicht blind in das Projekt kopiert oder als Quellcode behandelt.
- Geräte-/ADB-, VPN-, JARVIS/llama.cpp-, Release-/R8- und CI-Tests bleiben offen; siehe `FEHLT_NOCH.md`.

## Weitere Verbesserungen
- OpenVPN-Validierung: Größenlimit jetzt anhand der UTF-8-Bytegröße; unbekannte Inline-Blöcke werden abgewiesen und unerwartete schließende Blöcke nicht still akzeptiert.
- OpenVPN-Validierung: erlaubte Inline-Blöcke auf die unterstützten Zertifikats-/Schlüsselblöcke begrenzt.
- Diese Änderungen sind Quellcode-Verbesserungen, nicht als durch Build oder Gerätetest bestätigt.
