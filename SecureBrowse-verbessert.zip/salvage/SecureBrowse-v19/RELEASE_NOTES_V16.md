# SecureBrowse v16 – IPv6 Local DNS Shield

App version: 0.4.3 (versionCode 7)

## Implemented
- Added a dedicated IPv6 ULA address for the Local Shield DNS endpoint (`fd77:77::2`).
- Added only a /128 route for that virtual DNS endpoint; this does not route all IPv6 traffic through the local VPN and does not mask the public IP.
- Added IPv6 UDP DNS query parsing and response generation, including the mandatory IPv6 UDP pseudo-header checksum.
- Reuses the existing DNS policy: blocked domains receive local NXDOMAIN; permitted queries use the selected non-VPN upstream resolver.
- Rejects malformed, truncated, fragmented/extension-header (unsupported) and non-DNS packets rather than misparsing them.
- Added JVM tests for IPv6 parsing, reverse response addressing/ports, checksum validity, malformed packets and question mismatch.
- Preserved existing UI resources and layouts.

## Validation
- Compiled the pure Kotlin IPv6 codec and DNS policy with the installed Kotlin compiler.
- Executed a standalone IPv6 DNS smoke test: PASS (query parsing, response generation, checksum and truncation rejection).
- Full Android Gradle/JUnit suite and device-level VPN tests were not run in this environment.

## Limitations
- This remains a DNS-only local filter, not an IP-masking VPN or a full IPv6 firewall.
- IPv6 extension headers and fragmented IPv6 DNS packets are intentionally unsupported and ignored.
- IPv6 routing behavior, resolver selection, Private DNS forwarding and actual device DNS leak behavior require tests on Android devices/networks.
