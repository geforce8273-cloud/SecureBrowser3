# Verbesserungen an SecureBrowse (22.11.2026)

Nur Quelltext-Änderungen. Gebaut oder getestet wurde nichts (kein Gradle, Android SDK oder Netzwerk in dieser Umgebung).

## Sicherheit: OpenVPN-Prüfung
- Direktiven in Anführungszeichen oder mit Escape (`"up" script`, `u"p"`) und ein vorangestelltes UTF-8-BOM umgingen die Sperrliste. Beides wird jetzt vor der Prüfung normalisiert.
- Zusätzlich gesperrt: `iproute`, `pkcs11-providers`, `tls-export-cert`, `tmp-dir`. Zusätzlich als externe Datei erkannt: `askpass`, `http-proxy-user-pass`.
- Doppelten Test ersetzt; neue Tests für diese Fälle, Schreibweisen (`UP`, `--up`, Tab), kaputte Inline-Blöcke und das UTF-8-Byte-Limit.

## Browser: Adresseingabe
- `UrlTools.hasHost` lehnte Domains mit Umlauten (`bücher.de`) und Unterstrichen (`my_server:3000`) ab, weil `java.net.URI` dafür keinen Host liefert (mit Java nachgeprüft). Sie werden jetzt in der strengen Form `host[:port]` akzeptiert. Benutzerinfo, Klammern, Prozent-Escapes, leere Labels und ungültige Ports bleiben abgelehnt. Tests ergänzt.

## CI
- `permissions: contents: read`, Concurrency (ältere Läufe desselben Branches werden abgebrochen), Timeout 45 Minuten, Artefakt-Aufbewahrung 7 Tage, fehlende APK lässt den Job fehlschlagen.

## Bewusst nicht angefasst
- JARVIS/llama.cpp, Gradle-Versionen und UI-Dateien lassen sich nur mit echtem Build sinnvoll prüfen.
- `<connection>`-Blöcke in .ovpn werden weiter abgelehnt (fail-closed).
