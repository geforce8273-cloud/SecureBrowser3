# Release Notes v19 (Zwischenstand, Basis v18)

Umgebung dieser Runde: Gradle-Server, Google-Maven, Maven Central, dl.google.com und huggingface.co gesperrt; kein Android-Gerät. Keine UI-/Design-Änderung. Kein Quellcode des Produkts geändert.

## Tatsächlich ausgeführt
- ARM64-Cross-Build (Ubuntu aarch64-linux-gnu-gcc 13.3, CMake 3.28, Ninja) von llama.cpp b10000 + jarvis_jni.cpp mit Android-Log-Stub und OpenJDK-jni.h: ERFOLGREICH GELINKT (zweiter Versuch mit -fPIC): libjarvis_llama.so, ELF aarch64 (Linux/glibc, GCC 13.3, -march=armv8.2-a+dotprod), 197/197 Schritte, LOAD-Segmente mit 16-KB-Ausrichtung (0x4000), 6 exportierte JNI-Funktionen (nativeLoad/Unload/Generate/Cancel/LastError/CpuSupported), Namen passen zum Kotlin-Paket de.deinname.securebrowse.jarvis.LlamaBridge. NICHT getestet: Laden/Ausführen (kein Modell, kein Gerät), kein Android-NDK/bionic-Build.

## Nicht ausgeführt (Umgebung)
- Gradle-/AGP-Build, Debug-/Release-APK, R8, 16-KB-Prüfung der APK, Installation, Gerätetests.
- Echte Inferenz (kein GGUF-Modell), Token-Streaming/Abbruch/Entladen gegen echtes Modell, Flugmodus-Test.
- Nicht begonnen: Tor, Kill-Switch, IPv6-Firewall, Phishing-Schutz, Tresor/Passwortmanager, Chatverlauf-Speicherung.

## Verbesserungslauf 22.11.2026
- GitHub Actions erweitert um explizite SDK-/NDK-/CMake-Installation, vollständigen Debug-APK-Build mit nativer Bibliothek (sofern llama.cpp im Checkout liegt), Release/R8 und zipalign `-P 16`-Prüfung.
- NDK 28.2.13676358 fest gepinnt.
- Artifact-Aufbewahrung von APKs, Tests und Build-Logs auf 14 Tage erhöht.
- **Nicht ausgeführt:** Änderungen an Workflow und Gradle-Konfiguration sind noch nicht durch einen tatsächlichen CI-Lauf bestätigt. Kein APK-/Release-/Alignment-Erfolg behauptet.
- `ui/` und `res/` wurden nicht verändert.


### JARVIS voice/audio additions
- Added Android TTS voice-language helper, speech synthesis to audio file, and speech recognition intent/factory.
- Added M4A/AAC microphone recorder helper with cancellation cleanup.
- UI files and resources remain untouched. Not yet wired into UI or hardware-tested.


## JARVIS Live-Sprachgespräch – 22.11.2026
- `JarvisCallScreen.kt`: neues, schlichtes Sprachgesprächs-UI (warm, zurückhaltend, kein Tech-Panel).
- Mikrofon wird per Nutzertaste gestartet; Runtime-Permission; Recognizer-Dienst; Streaming-Antwort über vorhandene lokale Engine; Antwort wird per TTS gesprochen.
- In `JarvisScreen.kt` ist ein Einstieg „Mit JARVIS sprechen“ ergänzt und der Call in einem Vollbilddialog dargestellt.
- Design-Sperre: Ausnahme ausschließlich für die JARVIS-Call-UI (`ui/JarvisScreen.kt` und neue `ui/JarvisCallScreen.kt`); `res/` unverändert.
- Implementiert im Code, aber noch nicht kompiliert oder auf Hardware getestet. SpeechRecognizer kann externe Android-Dienste/Netzwerk verwenden.
