# Third-party model attribution — Qwen2.5-0.5B-Instruct-GGUF

SecureBrowse offers an optional one-time download of the following third-party model:

- Publisher: Qwen
- Repository: https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF
- File: `qwen2.5-0.5b-instruct-q4_k_m.gguf`
- Format: GGUF, Q4_K_M quantization
- Publisher-listed license: Apache-2.0
- Approximate download size: 491 MB
- SHA-256: `74a4da8c9fdbcd15bd1f6d01d621410d31c6fc00986f5eb687824e7b93d7a9db`

The model file is not bundled with SecureBrowse. The app downloads it only after the user confirms. The model is stored in app-private storage. Model inference is local when the native llama.cpp runtime is present; SecureBrowse does not send prompts to the model publisher.

Users should review the upstream model card and license before redistribution or other use. SecureBrowse is not the model publisher and does not warrant model output quality.
