# Verbesserungen – SecureBrowse v16

1. IPv6-DNS-Adresse `fd77:77::2` im Local Shield ergänzt.
2. IPv6 /128-DNS-Route im VpnService ergänzt.
3. IPv6 UDP DNS-Anfragen werden getrennt von IPv4 erkannt und verarbeitet.
4. Antworten tauschen Quell-/Zieladressen und UDP-Ports korrekt und berechnen die IPv6-Pflicht-Prüfsumme.
5. DNS-Policy und Upstream-Weiterleitung werden für IPv4 und IPv6 gemeinsam verwendet.
6. Neue Unit-Tests für Parsing, Antwort, Prüfsumme, ungültige Pakete und abweichende DNS-Fragen.
7. Versionsnummer auf 0.4.3 / VersionCode 7 angehoben.

Keine UI-, Farb-, Navigations- oder Animationsdateien geändert.
