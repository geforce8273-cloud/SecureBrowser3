# Lizenzen und Herkunft
Stand: 2026-11-22 · Verifikationsstatus: nicht verifiziert

- AndroidX / Jetpack Compose / Material 3: Apache License 2.0
- WireGuard Android Tunnel (com.wireguard.android:tunnel): Apache License 2.0
- llama.cpp (optional, per tools/add-llama-cpp.sh): MIT
- ics-openvpn (optional, per tools/add-openvpn.sh): GPLv2 → Entscheidung E1.1 offen
- Launcher-Icons (res/drawable/ic_launcher_*.xml): eigene Vektor-Dateien
- app/src/main/res/raw/drop.wav: mathematisch synthetisiert (tools/make-drop-wav.py, 220 ms, 22,05 kHz, mono), keine fremden Samples. Vorgeschlagene Lizenz: CC0 (PRUEFEN: bitte selbst bestätigen). Anhören auf dem A53 steht aus.
