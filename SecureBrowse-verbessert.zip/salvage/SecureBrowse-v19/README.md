# SecureBrowse – v0.5.0 · Local-first Ausbau (22.11.2026)

Early development foundation with a WireGuard VPN integration. **Not built or run in the authoring environment**; verify the first build and device behavior before relying on it. A VPN is only active after importing a valid profile and successfully connecting.

## Build (Android Studio, recommended)

1. Install Android Studio (current stable) and, via SDK Manager, **Android SDK Platform 37** + Build-Tools.
2. *File → Open* → select the folder containing `settings.gradle.kts`.
3. Android Studio reads `gradle/wrapper/gradle-wrapper.properties` and downloads **Gradle 9.6.0** (required by AGP 9.5.0).
4. *Build → Make Project*, then *Run* on a device.

## Command line (CachyOS)

The wrapper JAR/scripts are intentionally **not** shipped (the previous ZIP contained hand-made ones). Generate the real wrapper once with `tools/bootstrap-gradle-wrapper.sh` (verifies the Gradle checksum), or manually:

```bash
sudo pacman -S gradle jdk17-openjdk       # any JDK >= 17
gradle wrapper --gradle-version 9.6.0
./gradlew :app:assembleDebug
./gradlew :app:testDebugUnitTest          # UrlTools unit tests (never executed yet)
adb install app/build/outputs/apk/debug/app-debug.apk
```

## Checks required after the first successful sync

```bash
./gradlew :app:verifyNoForbiddenDependencies                                # fails on Play Services/Firebase/Sentry/...
./gradlew :app:dependencies --configuration releaseRuntimeClasspath > deps.txt
grep -Ei "gms|firebase|datatransport|crashlytics|sentry|billing|admob|mlkit" deps.txt   # must print nothing
./gradlew :app:processDebugMainManifest
# merged manifest: app/build/intermediates/merged_manifests/debug/ (exact path: PRUEFEN)
grep -E "uses-permission|exported|<receiver|<provider|<service" <merged AndroidManifest.xml>
```

Expected in the merged manifest: INTERNET, CAMERA, RECORD_AUDIO, `DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION` (androidx),
plus androidx.startup `InitializationProvider` and androidx.profileinstaller `ProfileInstallReceiver` (both come with Compose,
neither is a tracker). Anything else, especially `QUERY_ALL_PACKAGES`, `READ/WRITE_EXTERNAL_STORAGE`, `WAKE_LOCK`, must be investigated.

## What Phase 1 contains

- Compose + Material 3, light/dark, own palette (dynamic color implemented, off by default), adaptive icon incl. monochrome
- MVVM with StateFlow, manual DI, Navigation Compose (browser, tab grid, bookmarks, history)
- **One WebView per tab** (own back/forward history, title, progress), tabs persisted (URLs only) in DataStore
- URL/search detection (HTTPS first for bare hosts; also `name:port` servers without a dot; if the https attempt fails with a connection/handshake error, http:// is tried once automatically and the HTTP warning is shown), DuckDuckGo default, 3 search engines selectable
- HTTPS lock / HTTP warning / certificate-error banner (certificate errors show a warning dialog: cancel, or "continue anyway" for that one error, never remembered)
- Bookmarks, local history (500 max), share link, default-browser registration, receive shared text
- WebView hardening: no JS bridge, file+content access off, mixed content blocked, third-party cookies off, Safe Browsing enabled; WebView metrics opt-out enabled via manifest, only http/https load directly, `javascript:`/`file:`/`content:`/`data:` blocked,
  `mailto:`/`tel:`/`sms:`/`intent:` only after user gesture + confirmation (intent URIs sanitized: no component, no selector, no flags)
- File upload via Storage Access Framework (no storage permission), fullscreen video, HTTP auth dialog (credentials never saved)
- Website camera/microphone: own dialog first, Android permission only after "Allow", default deny; location always denied
- Pop-ups: only user-initiated windows open (as new tab), everything else is blocked
- Renderer crash handled (tab reloads instead of app crash)
- WireGuard userspace tunnel integration using the official Android tunnel library
- Import and validation of WireGuard `.conf` profiles; multiple named profiles
- VPN connection/disconnection controls and visible connection state
- Profiles encrypted locally with AES-GCM; encryption key stored in Android Keystore

## Known limits

Downloads (a hint is shown), find in page, print, QR-based VPN profile import, incognito (FLAG_SECURE), desktop mode, cookie/cache clearing UI,
full settings screen, tab thumbnails, complete EasyList-compatible ad blocker, media player. Tab scroll/form state is lost on process death (URLs are restored).

## v0.4.0 – Local-first AI + Shield hardening

- Optionaler **Local Shield VPN** (`LocalShieldVpnService`): on-device DNS filtering for a small built-in starter list. It has no SecureBrowse VPN gateway and does not change the public IP address.
- The shield routes only its synthetic IPv4 DNS address through Android `VpnService`; allowed DNS questions are forwarded through a protected socket to a validated non-VPN network resolver. Strict Android Private DNS is forwarded over TLS (DoT) without plaintext fallback; other resolver modes use UDP. Blocked names receive a local NXDOMAIN answer.
- JARVIS can optionally download the official Qwen2.5-0.5B-Instruct GGUF Q4_K_M model (about 491 MB) directly from the publisher's Hugging Face repository. This is a one-time model-file download, not cloud inference. The download is user-confirmed, HTTPS-only, checked against a pinned SHA-256 digest, checked for a valid GGUF header, and stored in app-private storage.
- Added stricter DNS query validation, IPv4-fragment rejection, resolver selection that prefers validated non-VPN internet networks, and DNS response transaction-ID/QR checks.
- Added pure DNS policy tests for response and multi-question rejection. Source-level tests still require the Gradle test task on a configured Android build machine.

### Local Shield limitations – read before enabling

- This is a DNS filter, **not** a full VPN tunnel, proxy, Tor connection, or IP anonymizer.
- It does not encrypt all device traffic. Allowed DNS requests go to the DNS resolver supplied by the active Wi-Fi/mobile network; strict Android Private DNS is preserved over DoT, while other modes may use UDP. SecureBrowse does not operate a resolver server.
- Current prototype handles IPv4 UDP DNS. IPv6 DNS, DNS-over-TCP fallback, encrypted DNS inside individual apps (DoH/DoT), and full blocklist updates are not covered. Some apps can bypass DNS filtering.
- The built-in blocklist is intentionally small and may block some legitimate subdomains or miss many trackers. It is not a replacement for a maintained filter-list engine.
- Android allows only one active VPN interface per user at a time. Stop Local Shield before connecting a WireGuard/OpenVPN profile or another VPN app.
- Do not treat this prototype as a security product until the Android build, packet routing, DNS behavior, battery use, network handover, and revocation paths have been tested on physical devices.

### JARVIS local AI – setup reality

- JARVIS is designed to run inference on-device through llama.cpp. The app does not need a paid API or a SecureBrowse AI server for that mode.
- The ZIP does **not** contain model weights or the llama.cpp source checkout. JARVIS can download the official Qwen GGUF weights after explicit confirmation, or import another GGUF file. Importing/downloading weights alone is not enough: the native runtime must also be added and built. Until then the UI correctly reports that the native library is missing.
- Model weights can be large and have individual licenses. Choose a GGUF model whose license permits your intended use, import it locally, then load it. Once the runtime and model are installed, prompts can be processed offline.
- A user-confirmed first-run download is available for the small Qwen2.5-0.5B-Instruct GGUF model. The model weights are not bundled in the APK. The first download needs internet and roughly 500 MB; afterward the model file is local. A native llama.cpp build is still required before the model can run.

## Security status (v0.4.1)

- WebView Safe Browsing is enabled globally and per WebView; WebView metrics opt-out remains enabled.
- A lightweight local ad/tracker domain filter is present. It is not a full EasyList engine and does not cover every request or redirect.
- See `RELEASE_NOTES_V11.md` and `SICHERHEITSKONZEPT_V11.md` for implemented changes, limitations, and release gates.

## VPN notes

- SecureBrowse does not provide VPN servers or free VPN access. The user must import a valid WireGuard configuration supplied by a VPN provider or their own server.
- Android's VPN consent dialog is required. System Always-on VPN and lockdown must be enabled by the user in Android settings; the app cannot silently enable them.
- The connection UI is not proof of internet reachability or anonymity. Test DNS, IPv4/IPv6 routing, reconnect behavior, and network changes on physical devices before release.
- The WireGuard tunnel dependency is `com.wireguard.android:tunnel:1.0.20260102` from Maven Central. See the official embedding guidance: https://github.com/WireGuard/wireguard-android#embedding.

## Decisions you should know about

1. **Cleartext policy.** Requirement 7 says any HTTP address must open, rule 12 forbids `usesCleartextTraffic="true"`.
   WebView obeys the network security config, so `network_security_config.xml` permits cleartext (attribute not used) and HTTP is warned about
   in the UI. All future own HTTP clients must be HTTPS-only. PRUEFEN: `http://neverssl.com` loads on device.
2. **No Room/KSP.** Master prompt prescribes DataStore; removing Room also removes the KSP/Kotlin version coupling.
3. **`androidx.webkit` omitted** until a feature really needs it (Phase 4), per "no unnecessary libraries".
4. `targetSdk 36`, `compileSdk 37`: PRUEFEN whether 37 should be the target by the time you publish.
5. Application ID `de.deinname.securebrowse` is a placeholder. Name check (brand collisions) is still open – do it before Phase 5.

## JARVIS – Phase 1 foundation

The Android app now contains a separate `jarvis` package, a persistent enable/disable setting, a SQLite memory database schema, an inference-engine contract, and an explicit unconfigured engine. The JARVIS entry is visible in the browser bottom navigation. This phase does **not** include a loaded language model, voice, vision, or web-research implementation; the UI reports inference as unavailable until a real runtime is integrated.


## JARVIS – Phase 3

Native llama.cpp runtime (NDK/JNI), streaming, cancel and memory protection: see `JARVIS_PHASE3.md`. Not yet built or run; read the "Ehrlicher Stand" section first.


## v0.4.1 – VPN profile vault hardening

- The encrypted VPN profile store no longer converts AES-GCM authentication, Base64, or JSON failures into an empty profile list.
- Reads now fail closed on an unreadable vault. Save/delete therefore cannot silently overwrite ciphertext after a Keystore/authentication failure.
- Profile writes validate name length/control characters, non-empty configuration, maximum configuration size (512 KiB), and supported backend type.
- Persistence writes use synchronous `commit()` and report a failed write instead of silently returning.
- Added JVM unit tests for the pure profile validation rules.
- No UI, theme, navigation, or animation files were changed.


## v0.4.2 – HTTPS downgrade protection

- Bare hostnames (for example `example.org` or `nas:8080`) resolve to HTTPS only.
- A failed HTTPS connection is never retried automatically over plaintext HTTP.
- Explicit `http://` URLs remain supported for local devices and legacy services and must be treated as insecure.
- TLS certificate errors remain blocked unless the user explicitly chooses the one-time override dialog.
- This is downgrade protection, not a strict HTTPS-only mode: explicit HTTP navigation is still possible.

## Release history

- **0.4.2 (versionCode 6):** prevents silent HTTPS-to-HTTP downgrade; bare hostnames remain HTTPS-only while explicitly typed HTTP remains available and visibly insecure.

## SecureBrowse v16
Version 0.4.3 ergänzt IPv6-UDP-DNS für den Local Shield über eine dedizierte IPv6-ULA-DNS-Adresse. Der Tunnel routet nur diese einzelne DNS-Adresse (/128), nicht den gesamten IPv6-Verkehr. Es handelt sich weiterhin um einen lokalen DNS-Filter und nicht um einen IP-maskierenden VPN-Tunnel oder vollständige IPv6-Firewall.
