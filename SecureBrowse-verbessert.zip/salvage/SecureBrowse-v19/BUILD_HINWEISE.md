# GitHub Build

1. Repo auf GitHub erstellen und den gesamten Projektordner inklusive `.github` und `gradle/libs.versions.toml` hochladen.
2. GitHub-Reiter Actions öffnen.
3. Workflow „SecureBrowse Android build“ ausführen/abwarten.
4. Bei erfolgreichem Lauf das Artefakt `SecureBrowse-apks-and-tests` herunterladen.

Hinweis: Das ZIP der ursprünglichen Quelle war beschädigt und enthält nicht die llama.cpp-Unterquellen. Deshalb wird JARVIS native Inferenz im Build nicht mitgeliefert. Die APK ist nicht verifiziert, bis der Workflow erfolgreich läuft.
