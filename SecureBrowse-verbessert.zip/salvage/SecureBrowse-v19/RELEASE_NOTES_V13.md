# SecureBrowse v0.4.0 — Local-first AI + Shield hardening

## JARVIS
- Added an optional, user-confirmed download for Qwen2.5-0.5B-Instruct GGUF Q4_K_M (~491 MB) from the official Qwen Hugging Face repository.
- Pinned SHA-256 validation and GGUF header validation before validated replacement.
- Download is stored in app-private storage; cancellation removes the partial file.
- Prompts are still processed only by the local llama.cpp runtime when that runtime is present.
- Clear warning: the native llama.cpp source checkout/build is still a separate required setup step. This archive does not pretend that an APK with working inference has been built.

## Local Shield
- DNS parser now rejects response packets, non-standard opcodes, multiple-question packets, malformed names, and compressed names.
- IPv4 fragments are rejected instead of being partially parsed as DNS.
- Upstream resolver selection prefers validated internet networks that are not VPN networks.
- Upstream DNS responses are checked for matching transaction IDs, response bit, and exact question.
- Strict Android Private DNS is forwarded over TLS (DoT) with certificate hostname verification; the service does not downgrade strict Private DNS to plaintext UDP.

## Limits
- Local Shield is still DNS-only IPv4 UDP filtering, not an IP-changing VPN. IPv6 DNS, DoT/DoH bypasses, TCP fallback, and a full filter-list engine remain unsupported.
- The Qwen 0.5B model is a small starter model; answer quality and speed are limited by the model and phone hardware.
- No Android APK build or physical-device test was possible in the authoring environment. Build and device verification remain release blockers.
