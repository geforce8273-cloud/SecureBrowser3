# RISIKEN.md – SecureBrowse (SBS)
Stand: 2026-11-22 · Verifikationsstatus: nur Quelltext gelesen, nichts gebaut, nichts getestet (nicht verifiziert)

| ID | Risiko | Wahrsch. | Auswirkung | Gegenmaßnahme | Status |
|----|--------|----------|-----------|---------------|--------|
| R1 | jarvis_jni.cpp (48 llama_-Aufrufe) wurde aus dem Gedächtnis geschrieben und passt evtl. nicht zur echten llama.h | hoch | JARVIS baut nicht | Tag pinnen, Kompilierfehler Zeile für Zeile beheben; M1 läuft ohne Native | offen (M4) |
| R2 | AGP-9.5-/Versionskatalog-Fehler beim ersten Sync (AGP 9.5.0 und Gradle 9.6.0 sind laut developer.android.com bzw. docs.gradle.org real; Kotlin 2.4.10, Icons 1.7.8, Lifecycle 2.10.0, DataStore 1.2.0 noch PRUEFEN) | hoch | M1 blockiert | Versionen einzeln prüfen, ersten echten Log analysieren | offen (M1) |
| R3 | CI brach wegen fehlendem gradle-wrapper.jar ab | hoch | Kein APK | Workflow nutzt jetzt gradle/actions/setup-gradle mit Gradle 9.6.0 (Action-Version PRUEFEN, erster Lauf steht aus) | umgesetzt, nicht verifiziert |
| R4 | SIGILL auf dem A53 durch falsche CPU-Flags | mittel | Nativer Absturz | -march=armv8.2-a+dotprod, nativeCpuSupported() | offen |
| R5 | OpenVPN (ics-openvpn: GPLv2, Submodule, NDK) | mittel | Lizenz-/Build-Konflikt | Erst WireGuard stabil, Entscheidung E1.1 | offen |
| R6 | Tap-Effekt verursacht Ruckler | mittel | Frame-Drops | Profiling auf A53 | offen (M2) |
| R7 | Prompt-Injection über Seiteninhalt | mittel | Manipulation | Regeln aus D13.7 vor Feature "Seite zusammenfassen" | offen (M6) |
| R8 | Unit-Tests nie ausgeführt | mittel | Unbekannte Fehler | Mit M1 ausführen | offen (M1) |
| R9 | Namens-/Markenkollision "SecureBrowse", Application-ID Platzhalter | mittel | Umbenennung | Vor M7 prüfen | offen |
| R10 | Doku widerspricht Code (README "Phase 1", Downloads/AdBlocker; PRUEFBERICHT_ZUSATZ nennt Klassen, die es nicht gibt) | mittel | Falsches Vertrauen | Nach jedem Meilenstein abgleichen | offen |
| R11 | Tor-Modus nur als Gerüst; WebView kann Tor-Browser-Fingerprinting-Schutz nicht erreichen; Engine/androidx.webkit-Version offen | hoch | Falsches Sicherheitsgefühl | Kein "anonym" in der UI, Fail-closed-Policy, TOR.md, Entscheidung offen | offen |
