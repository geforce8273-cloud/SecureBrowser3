# JARVIS – Verbesserungspaket

## Änderungen
- Erweiterte Standard-Systemanweisung: Ehrlichkeit über Fähigkeiten, Umgang mit untrusted web/file text,
  defensive Sicherheitsantworten, Sprache und Unsicherheit.
- Chat-Kontext wird vor JNI-Einspeisung auf Steuer-/Bidirektionalzeichen bereinigt und auf 12.000 Zeichen
  je Nachricht begrenzt.
- Unit-Tests ergänzt für Bereinigung und Größenbegrenzung.

## Grenzen
Diese Änderungen verbessern Verhalten und Robustheit des Prompt-Eingangs, nicht die Modellgewichte.
Kein Android-Build, JNI-Integrationstest oder Gerätetest ist in dieser Änderung als bestanden ausgewiesen.
