# STATUS – SecureBrowse v18 Arbeitsstand (Basis v17, versionName 0.6.0, versionCode 9)

Lies zuerst diese Datei und RELEASE_NOTES_V17.md. Nicht das ganze Projekt neu untersuchen.

## Regel Nr. 1: Design-Sperre
ui/ und res/ sind identisch mit v16 und dürfen nicht verändert werden. Sichtbare Änderungen nur nach ausdrücklicher Erlaubnis des Besitzers.

## Was funktioniert (mit Teststufe)
- llama.cpp b10000 eingebunden (gekürzt, MIT) – CMake-Konfiguration und Host-Build (x86_64, NICHT Android) 193/193 erfolgreich.
- jarvis_jni.cpp kompiliert gegen echte b10000-Header und linkt gegen die echten statischen Bibliotheken (Host).
- Nativer UTF-8-Stream-Test bestanden (Host).
- GgufHeader.kt (Erkennung abgeschnittener GGUF-Dateien): 7/7 Tests bestanden, mit Kotlin 2.4.10 und JUnit-Ersatz (kein echtes JUnit).
- Gradle-Wrapper (jar, gradlew, gradlew.bat) aus Gradle 9.6.0 erzeugt; SHA-256 der Distribution stimmt mit gradle-wrapper.properties überein.

## Nicht getestet / funktioniert nicht nachgewiesen
- Android-Gradle-Build, NDK/ARM-Kompilierung, APK, Test auf Gerät.
- Echte KI-Inferenz (kein GGUF-Modell verfügbar). SHA-256 des Qwen-Modells nicht gegen die Originalquelle geprüft.
- JNI-Integrationstest (Laden, Streaming, Abbruch, Entladen) existiert nicht.
- Geänderte JarvisModelManager.kt nicht kompiliert (braucht Android SDK).
- v16-Unit-Tests in v17 nicht erneut ausgeführt; WebPermissionPolicyTest und VpnProfileValidationTest brauchen Android.
- Nicht begonnen: DNS/IPv6-Verbesserungen, Phishing-Schutz, Tor, Passwortmanager/Tresor.

## v18 – in dieser Runde ergänzt
- URL-Eingaben mit User-Info und unsichtbaren Unicode-Format-/Bidi-Zeichen werden abgelehnt.
- JARVIS-Seitentextfilter entfernt Format-/Bidi-Zeichen und erzwingt maximal 6.000 Zeichen.
- 28 gezielte JVM-Regressionstests bestanden (Kotlin-Compiler + JUnit-Ersatz, kein Gradle).
- CI richtet Android-SDK explizit ein; Debug-APK-Job deaktiviert native JARVIS-Bibliothek bewusst.
- UI-/Ressourcen-Designsperre eingehalten. Details: RELEASE_NOTES_V18.md.

## Nächste Aufgabe
Phase A: GitHub-Actions-Workflow (.github/workflows) für echten Android-Build (SDK, NDK, arm64-v8a, Debug-APK, Unit-Tests). Fehlerlogs vom Besitzer beheben.

## Entscheidungen
- llama.cpp fest auf b10000, weil jarvis_jni.cpp diese API nutzt (neuere Tags haben andere API).
- Native Bibliothek nur arm64-v8a, ohne armv8.7-Instruktionen, 16-KB-Seiten.
- Modell: Qwen2.5-0.5B-Instruct Q4_K_M (ca. 491 MB).

## Risiken
- IPv6-DNS-Schutz ist KEIN vollständiger IPv6-Firewall- oder VPN-Schutz.
- TorMode ist ohne echte Tor-Anbindung nicht funktionsfähig.
- Lokaler VPN-Schutz ändert die IP nicht (dafür braucht es einen entfernten Endpunkt).

## Hinweise für den nächsten Chat
- Hier erreichbar: GitHub, PyPI, npm, Ubuntu-Archive. Gesperrt: services.gradle.org, huggingface.co, dl.google.com. Gradle-Distribution gibt es unter github.com/gradle/gradle-distributions.
- Bei Host-Builds mit 1 CPU: Ninja mit setsid nohup im Hintergrund starten, sonst bricht er ab.
- android/log.h ist beim Host-Test nur ein Stub; JNI-Header kommen aus OpenJDK.

## v19 – Teststufen (Stand dieser Runde)
Stufen: Nicht implementiert / Implementiert, nicht getestet / Teilweise getestet / Erfolgreich getestet / Auf echter Hardware bestätigt
- Android-Gradle-Build, Debug-/Release-APK, Installation: Implementiert, nicht getestet (Server gesperrt).
- Native ARM64-Kompilierung + Link (Linux-Cross, kein NDK): Erfolgreich getestet für Kompilieren/Linken/16-KB-Ausrichtung/JNI-Symbole; Ausführen nicht getestet. Siehe RELEASE_NOTES_V19.md.
- JARVIS-Inferenz, Streaming, Abbruch, Gesamttest in der APK, Flugmodus: Implementiert, nicht getestet (kein Modell, kein Gerät).
- Tor, Kill-Switch, IPv6-Firewall, Phishing-Schutz, Tresor, Chatverlauf: Nicht implementiert.
- Auf echter Hardware bestätigt: nichts.

## v19 – Verbesserungslauf 22.11.2026
- CI-Workflow erweitert: SDK-Plattform/Build-Tools, NDK 28.2.13676358 und CMake installieren; Debug und Release (R8) bauen; 16-KB-APK-Alignment mit zipalign prüfen; Test-/APK-Artefakte sichern. **Workflow nicht ausgeführt; daher alles nur implementiert, nicht getestet.**
- NDK-Version im Gradle-Projekt fest gepinnt, damit CI reproduzierbarer ist.
- UI-/Ressourcen-Sperre bleibt bestehen.


## JARVIS Voice extension (22.11.2026)
- Implementiert, nicht getestet: Android TTS facade and audio-file synthesis, language/voice selection preference, SpeechRecognizer setup, M4A audio recording helper.
- Nicht implementiert: UI wiring (ui/ locked), realtime duplex call session transport, call UX, audio loopback/echo cancellation.
- Nicht auf Hardware bestätigt; offline speech recognition is device/service dependent.


## JARVIS Live-Sprachgespräch – 22.11.2026
- `JarvisCallScreen.kt`: neues, schlichtes Sprachgesprächs-UI (warm, zurückhaltend, kein Tech-Panel).
- Mikrofon wird per Nutzertaste gestartet; Runtime-Permission; Recognizer-Dienst; Streaming-Antwort über vorhandene lokale Engine; Antwort wird per TTS gesprochen.
- In `JarvisScreen.kt` ist ein Einstieg „Mit JARVIS sprechen“ ergänzt und der Call in einem Vollbilddialog dargestellt.
- Design-Sperre: Ausnahme ausschließlich für die JARVIS-Call-UI (`ui/JarvisScreen.kt` und neue `ui/JarvisCallScreen.kt`); `res/` unverändert.
- Implementiert im Code, aber noch nicht kompiliert oder auf Hardware getestet. SpeechRecognizer kann externe Android-Dienste/Netzwerk verwenden.
