# SecureBrowse v15 – HTTPS Downgrade Protection

App version: 0.4.2 (versionCode 6)

## Implemented
- Removed automatic fallback from a failed HTTPS navigation to plaintext HTTP.
- Bare hostnames, IPv4 addresses, and local hostnames resolve to HTTPS without a fallback URL.
- Explicitly typed `http://` addresses remain supported for local devices and legacy services; the browser continues to mark these pages as insecure.
- Removed obsolete fallback state, callback handling, and UI strings.
- Added/updated JVM unit cases for HTTPS-only resolution of bare hosts and explicit HTTP behavior.
- Preserved existing UI layout and styling.

## Validation performed
- Compiled the pure Kotlin URL and link helper sources with the locally available Kotlin compiler.
- Executed five focused navigation-policy assertions successfully.
- Parsed all 13 XML resources successfully.
- Checked Kotlin source files for UTF-8 readability and NUL bytes.
- Source search confirms the HTTP fallback map, error-triggered downgrade path, and fallback UI strings are gone.

## Not performed / limitations
- Full Gradle/JUnit suite was not run: this environment has no Gradle executable and the repository has no `gradle-wrapper.jar`.
- Android APK build and device/emulator tests were not run: Android SDK/Gradle build environment is unavailable.
- This release adds downgrade protection, not a strict HTTPS-only mode: users can still explicitly enter an `http://` URL.
