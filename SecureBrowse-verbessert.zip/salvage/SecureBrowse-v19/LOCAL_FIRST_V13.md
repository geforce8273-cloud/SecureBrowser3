# SecureBrowse v0.4.0 — Local-first setup

## No account, no subscription, no rented SecureBrowse server

SecureBrowse does not require an account, paid AI API, cloud inference service, or VPN gateway for its local features.

## JARVIS local AI

1. Open JARVIS and choose **Kostenloses KI-Modell herunterladen**.
2. Confirm the one-time download (about 491 MB). It comes from the official Qwen repository on Hugging Face over HTTPS.
3. The app verifies a pinned SHA-256 digest and the GGUF header before it installs the model in app-private storage.
4. Build SecureBrowse with the llama.cpp native runtime using `tools/add-llama-cpp.sh <tag-or-commit>` and the Android NDK.
5. Load the model in JARVIS. Once loaded, prompts are processed locally and can work without internet.

The model is Qwen2.5-0.5B-Instruct, Q4_K_M, publisher-listed under Apache-2.0. It is a small starter model, not a frontier-scale assistant. The app archive does not bundle the 491 MB model or llama.cpp sources.

## Free local DNS protection

1. Open the VPN page.
2. Tap **Kostenlosen lokalen Schutz aktivieren**.
3. Accept Android's VPN permission dialog.
4. Android displays an ongoing notification while the DNS filter is active.

This mode uses Android VpnService as a local DNS filter. It does not send all internet traffic through a VPN exit, does not encrypt all traffic, and does not change the public IP address. Allowed DNS questions are sent to a DNS resolver supplied by the current non-VPN network. Apps using their own DoH/DoT may bypass this prototype. Android permits only one active VPN interface at a time.

## What still needs finishing before release

- Build and test the Android app with a real Gradle wrapper, SDK, NDK, CMake, and pinned llama.cpp source.
- Test the local DNS tunnel on physical Android devices (Wi-Fi/mobile handover, private DNS, IPv6, DNS timeouts, revocation, and battery use).
- Add IPv6 DNS and DNS-over-TCP support, stronger upstream DNS privacy, and a maintained blocklist engine.
- Verify model load/generation, memory pressure, cancellation, and offline operation on the target phone.

No server or subscription can make a no-server IP-masking VPN possible: changing the public exit IP requires a remote endpoint somewhere. The included local Shield is the free no-server alternative for on-device DNS filtering only.
