# Dependency versions – checked 2026-11-21

| Component | Version | Source / status |
|---|---|---|
| Android Gradle Plugin | 9.5.0 | developer.android.com/build/releases/gradle-plugin – stable; needs Gradle 9.6.0, max API 37 |
| Gradle | 9.6.0 | AGP 9.5 release notes (minimum = default) |
| Kotlin | 2.4.10 | 2.4.0 confirmed (kotlinlang.org, 2026-06), 2.4.10 bug-fix release seen on GitHub tag list – **PRUEFEN** |
| Compose ui/foundation/runtime | 1.13.0 | developer.android.com/latest-updates (2026-11-18, stable) |
| Compose Material 3 | 1.5.0 | same page, stable |
| Material icons extended | 1.7.8 | **PRUEFEN** – icon artifacts are no longer released with Compose 1.13; if resolution fails use the newest 1.7.x |
| activity-compose | 1.13.0 | releases/activity – 1.13.0 stable, **1.14.x is alpha** (old ZIP used it) |
| core-ktx | 1.19.1 | latest-updates page, stable |
| lifecycle-runtime-compose | 2.10.0 | **PRUEFEN** – 2.12.0 is alpha (old ZIP used it); 2.10.0 assumed stable |
| navigation-compose | 2.10.2 | latest-updates page, stable |
| datastore-preferences | 1.2.0 | **PRUEFEN** |
| junit (test only) | 4.13.2 | unit tests for URL logic |

Not used on purpose: Room/KSP, androidx.webkit (later), Play Services, Firebase, any analytics.


## VPN addition (2026-11-21)

- `com.wireguard.android:tunnel:1.0.20260102` — official embeddable WireGuard Android userspace backend, Apache-2.0.
- `com.android.tools:desugar_jdk_libs:2.1.5` — core-library desugaring required by the WireGuard Android library's Java 8+ API usage.
- Official embedding guide: https://github.com/WireGuard/wireguard-android#embedding
- The AAR contributes its own `GoBackend$VpnService` manifest declaration. Do not duplicate that service in the app manifest.


## Native (Phase 3)

- llama.cpp: pinned by tag/commit via `tools/add-llama-cpp.sh` (MIT). Not downloaded in this ZIP.
- Android NDK: AGP default version (not pinned; **PRUEFEN** on first build). CMake 3.22.1 from the SDK Manager.
- Target ABI for the native library: arm64-v8a only, `armv8.2-a+dotprod`.
